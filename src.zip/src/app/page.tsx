import Link from "next/link";
import DdddddExerciseCard, { ExerciseCardProps } from "./exercise-card";
import exercisesData from './exercises.json';
import WakaTimeStats from "./wakatime-stats";
import Footer from "./components/footer";
import MarioBackground from "./components/mario-background";

function Navbar() {
  return (
    <nav className="mario-nav fixed top-0 left-0 right-0 text-white p-4 shadow-lg w-full z-50">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold hover:text-yellow-300 transition-colors duration-300 tracking-wider flex items-center gap-3">
          <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center border-2 border-white mario-coin">
            <span className="text-sm font-black text-white">M</span>
          </div>
          <span className="mario-text-gradient text-white">超级学习工坊</span>
        </Link>
        <div className="hidden md:flex space-x-8 text-base">
          <Link href="/" className="hover:text-yellow-300 transition-colors duration-300 relative group font-semibold">
            🏠 首页
            <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-yellow-300 transition-all duration-300 group-hover:w-full"></div>
          </Link>
          <Link href="/practice/my-app" className="hover:text-yellow-300 transition-colors duration-300 relative group font-semibold">
            🎮 开始闯关
            <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-yellow-300 transition-all duration-300 group-hover:w-full"></div>
          </Link>
          <Link href="#courses" className="hover:text-yellow-300 transition-colors duration-300 relative group font-semibold">
            📚 课程项目
            <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-yellow-300 transition-all duration-300 group-hover:w-full"></div>
          </Link>
          <Link href="#wakatime-stats" className="hover:text-yellow-300 transition-colors duration-300 relative group font-semibold">
            📊 时长统计
            <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-yellow-300 transition-all duration-300 group-hover:w-full"></div>
          </Link>
          <Link href="/practice/embed-demo" className="hover:text-yellow-300 transition-colors duration-300 relative group font-semibold">
            🤖 智能问答
            <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-yellow-300 transition-all duration-300 group-hover:w-full"></div>
          </Link>
          <Link href="#about" className="hover:text-yellow-300 transition-colors duration-300 relative group font-semibold">
            ℹ️ 关于
            <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-yellow-300 transition-all duration-300 group-hover:w-full"></div>
          </Link>
        </div>
        
        {/* 移动端菜单按钮 */}
        <div className="md:hidden">
          <button className="text-white hover:text-yellow-300 transition-colors duration-300">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </nav>
  );
}

function CourseNavbar() {
  const courses = ["全部项目", "HTML", "CSS", "JavaScript", "React", "Next.js"];
  
  return (
    <div className="mario-section p-6 mb-8">
      <div className="flex flex-wrap justify-center gap-4">
        {courses.map((course, index) => (
          <button
            key={course}
            className={`mario-button px-6 py-3 text-sm font-bold transition-all duration-300 hover:scale-105 ${
              index === 0 ? 'bg-green-600 border-green-800' : ''
            }`}
          >
            {course}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <MarioBackground>
      <Navbar />
      <main className="container mx-auto px-4 pt-24 pb-12">
        {/* 英雄横幅区域 */}
        <div className="w-full pt-20 pb-12">
          <div className="container mx-auto px-4">
            <div className="text-center relative">
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent"></div>
              
              <h1 className="text-6xl md:text-8xl font-black mario-text-gradient mb-6 drop-shadow-lg tracking-wide">
                🎮 超级学习工坊
              </h1>
              
              <div className="flex items-center justify-center gap-4 mb-6">
                <div className="w-12 h-px bg-gradient-to-r from-transparent to-red-600"></div>
                <div className="mario-coin w-4 h-4 rounded-full"></div>
                <div className="w-16 h-px bg-gradient-to-r from-red-600 to-blue-700"></div>
                <div className="mario-coin w-4 h-4 rounded-full"></div>
                <div className="w-12 h-px bg-gradient-to-r from-blue-700 to-transparent"></div>
              </div>
              
              <p className="text-xl md:text-2xl text-gray-700 max-w-4xl mx-auto tracking-wide leading-relaxed mb-8">
                🏃‍♂️ 像马里奥一样在编程世界中不断探索和闯关！<br/>
                从HTML基础到Next.js全栈，逐步提升编程技能！
              </p>
              
              <div className="flex justify-center gap-4">
                <Link href="/practice/my-app" className="mario-button px-8 py-4 text-lg font-bold">
                  🚀 开始闯关
                </Link>
                <Link href="#courses" className="mario-button px-8 py-4 text-lg font-bold bg-green-600 border-green-800">
                  📖 查看教程
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* 课程项目导航 */}
        <CourseNavbar />

        {/* 练习板块 */}
        <section id="courses" className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-black mario-text-gradient mb-4 flex items-center justify-center gap-4">
              🎯 编程闯关之旅
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              像马里奥收集金币一样，逐步收集编程技能。每个关卡都在前一个基础上添加新的挑战！
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {exercisesData.map((exercise: ExerciseCardProps) => (
              <DdddddExerciseCard
                key={exercise.id}
                id={exercise.id}
                title={exercise.title}
                description={exercise.description}
                imageUrl={exercise.imageUrl}
                link={exercise.link}
                tags={exercise.tags}
              />
            ))}
          </div>
        </section>

        {/* 问答板块 */}
        <section className="mario-section p-8 mb-20">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black mario-text-gradient mb-4 flex items-center justify-center gap-4">
              🤖 智能问答助手
            </h2>
            <p className="text-lg text-gray-600">像请教蘑菇王一样，获得编程问题的解答！</p>
          </div>
          
          <div className="max-w-4xl mx-auto text-center">
            <Link 
              href="/practice/embed-demo" 
              className="mario-button inline-flex items-center gap-2 px-8 py-4 text-lg font-bold bg-blue-600 border-blue-800 hover:bg-blue-700 transition-colors"
            >
              🚀 开始提问
            </Link>
          </div>
        </section>

        {/* Wakatime统计板块 */}
        <section id="wakatime-stats" className="mario-section p-8 mb-20">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black mario-text-gradient mb-4 flex items-center justify-center gap-4">
              📊 编程统计数据
            </h2>
            <p className="text-lg text-gray-600">像马里奥查看游戏统计一样，看看你的编程成长数据！</p>
          </div>
          
          <WakaTimeStats />
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
            <div className="mario-card p-6 text-center">
              <div className="level-badge mx-auto mb-3">86</div>
              <h3 className="font-bold text-gray-800 mb-2">总编程时长</h3>
              <p className="text-sm text-gray-600">小时</p>
            </div>
            <div className="mario-card p-6 text-center">
              <div className="level-badge mx-auto mb-3">2</div>
              <h3 className="font-bold text-gray-800 mb-2">每日平均</h3>
              <p className="text-sm text-gray-600">小时</p>
            </div>
            <div className="mario-card p-6 text-center">
              <div className="level-badge mx-auto mb-3">12</div>
              <h3 className="font-bold text-gray-800 mb-2">项目数量</h3>
              <p className="text-sm text-gray-600">个</p>
            </div>
            <div className="mario-card p-6 text-center">
              <div className="level-badge mx-auto mb-3">5</div>
              <h3 className="font-bold text-gray-800 mb-2">掌握语言</h3>
              <p className="text-sm text-gray-600">种</p>
            </div>
          </div>
        </section>

        {/* 关于板块 */}
        <section id="about" className="mario-section p-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black mario-text-gradient mb-4 flex items-center justify-center gap-4">
              ℹ️ 关于超级学习工坊
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              让编程学习像玩马里奥游戏一样有趣！
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="mario-card p-6 text-center">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">学习目标</h3>
              <p className="text-gray-600">
                通过游戏化的方式掌握前端开发技能，从基础到进阶，循序渐进。
              </p>
            </div>
            <div className="mario-card p-6 text-center">
              <div className="text-4xl mb-4">🎮</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">学习方式</h3>
              <p className="text-gray-600">
                每个关卡都有明确的学习目标和实践任务，像玩游戏一样完成挑战。
              </p>
            </div>
            <div className="mario-card p-6 text-center">
              <div className="text-4xl mb-4">🌟</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">学习成果</h3>
              <p className="text-gray-600">
                通过项目实战和关卡挑战，逐步构建个人作品集。
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </MarioBackground>
  );
}
