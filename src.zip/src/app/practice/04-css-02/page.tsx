'use client';
import Link from 'next/link';
import { useState } from 'react';
import MarioBackground from "../../components/mario-background";

export default function JavaScriptBasicLevel() {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [currentExample, setCurrentExample] = useState('变量声明');

  const jsTopics = [
    { name: '变量', symbol: 'let', desc: '数据存储容器', code: 'let marioLife = 3;' },
    { name: '常量', symbol: 'const', desc: '不可改变的值', code: 'const GAME_NAME = "Super Mario";' },
    { name: '函数', symbol: 'function', desc: '可重用代码块', code: 'function jumpMario() { ... }' },
    { name: '对象', symbol: '{}', desc: '属性和方法集合', code: 'const mario = { x: 0, y: 0 };' },
    { name: '数组', symbol: '[]', desc: '有序数据列表', code: 'const coins = [1, 2, 3, 4, 5];' },
    { name: '条件', symbol: 'if', desc: '判断与分支', code: 'if (coins > 0) { ... }' },
    { name: '循环', symbol: 'for', desc: '重复执行代码', code: 'for (let i = 0; i < 5; i++) { ... }' },
    { name: '事件', symbol: 'click', desc: '用户交互响应', code: 'button.onclick = jumpMario;' }
  ];

  const codeExamples = [
    { 
      name: '变量声明', 
      desc: '存储马里奥的游戏数据', 
      code: `// 马里奥游戏变量
let marioX = 100;     // 马里奥的X坐标
let marioY = 200;     // 马里奥的Y坐标
let coins = 0;        // 收集的金币数量
let lives = 3;        // 马里奥的生命数
let gameSpeed = 5;    // 游戏速度`,
      color: 'from-red-400 to-red-600'
    },
    { 
      name: '函数定义', 
      desc: '创建马里奥的动作函数', 
      code: `// 马里奥跳跃函数
function jumpMario() {
  marioY -= 50;  // 向上跳跃
  console.log("马里奥跳跃！");
}

// 收集金币函数
function collectCoin() {
  coins += 1;
  console.log("收集到金币！总数：" + coins);
}`,
      color: 'from-green-400 to-green-600'
    },
    { 
      name: '条件判断', 
      desc: '根据游戏状态做出判断', 
      code: `// 游戏状态判断
if (lives <= 0) {
  console.log("游戏结束！");
  gameOver();
} else if (coins >= 100) {
  console.log("获得额外生命！");
  lives += 1;
} else {
  console.log("继续冒险！");
}`,
      color: 'from-blue-400 to-blue-600'
    },
    { 
      name: '循环遍历', 
      desc: '处理游戏中的重复操作', 
      code: `// 生成多个金币
for (let i = 0; i < 5; i++) {
  console.log("第" + (i + 1) + "个金币已生成");
}

// 马里奥移动动画
let steps = 0;
while (steps < 10) {
  marioX += 5;  // 每次移动5像素
  steps++;
}`,
      color: 'from-purple-400 to-purple-600'
    },
    { 
      name: '对象操作', 
      desc: '管理马里奥角色数据', 
      code: `// 马里奥角色对象
const mario = {
  x: 100,
  y: 200,
  speed: 5,
  lives: 3,
  
  // 移动方法
  move: function(direction) {
    if (direction === 'right') {
      this.x += this.speed;
    }
  }
};

console.log(mario.x);  // 访问属性
mario.move('right');   // 调用方法`,
      color: 'from-yellow-400 to-yellow-600'
    }
  ];

  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-12 relative">
            <div className="absolute inset-0 opacity-10">
              <div className="flex justify-center items-center h-full">
                <div className="text-9xl text-blue-200 font-mono transform rotate-6">JS</div>
              </div>
            </div>
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">6</div>
            <h1 className="text-3xl md:text-4xl font-black mario-text-gradient mb-4 tracking-widest drop-shadow relative z-10">
              💻 JavaScript基础关卡
            </h1>
            <p className="text-lg text-gray-800 relative z-10">给马里奥的世界添加交互魔法！</p>
          </div>

          {/* JavaScript基础概念展示 */}
          <section className="mb-12 mario-section p-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🎯 JavaScript核心概念</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {jsTopics.map((topic, index) => (
                <div
                  key={index}
                  className={`text-center p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedTopic === topic.name 
                      ? 'bg-red-500 text-white shadow-lg mario-glow' 
                      : 'mario-card hover:bg-blue-100 text-gray-700'
                  }`}
                  onClick={() => setSelectedTopic(selectedTopic === topic.name ? null : topic.name)}
                >
                  <div className="text-2xl font-mono mb-2 font-bold">{topic.symbol}</div>
                  <h3 className="font-bold text-sm mb-1">{topic.name}</h3>
                  <p className="text-xs opacity-80">{topic.desc}</p>
                </div>
              ))}
            </div>
            {selectedTopic && (
              <div className="mario-card p-6 border-l-4 border-red-500">
                <h4 className="font-bold text-red-700 mb-3">{selectedTopic} 详解</h4>
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm">
                  <code className="text-green-400">
                    {jsTopics.find(t => t.name === selectedTopic)?.code}
                  </code>
                </div>
                <p className="text-gray-700 mt-3 text-sm">
                  {jsTopics.find(t => t.name === selectedTopic)?.desc}，
                  是JavaScript编程的重要概念，就像马里奥游戏中的基本元素一样重要！
                </p>
              </div>
            )}
          </section>

          {/* 代码示例展示 */}
          <section className="mb-12 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🚀 马里奥主题代码示例</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              {codeExamples.map((example, index) => (
                <div
                  key={index}
                  className={`text-center p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-105 ${
                    currentExample === example.name 
                      ? 'bg-green-600 text-white shadow-xl' 
                      : 'mario-card hover:bg-green-50 text-gray-700'
                  }`}
                  onClick={() => setCurrentExample(example.name)}
                >
                  <div className={`w-12 h-12 mx-auto mb-3 bg-gradient-to-br ${example.color} rounded-full flex items-center justify-center transition-all duration-500`}>
                    <span className="text-white font-bold text-lg">{index + 1}</span>
                  </div>
                  <h3 className="font-bold text-sm mb-1">{example.name}</h3>
                  <p className="text-xs opacity-80">{example.desc}</p>
                </div>
              ))}
            </div>
            <div className="mario-card p-6">
              <h3 className="text-xl font-bold mario-text-gradient mb-4 text-center">
                {codeExamples.find(e => e.name === currentExample)?.name}
              </h3>
              <div className="bg-gray-900 rounded-lg p-6 font-mono text-sm overflow-x-auto">
                <pre className="text-green-400 whitespace-pre-wrap">
                  {codeExamples.find(e => e.name === currentExample)?.code}
                </pre>
              </div>
              <p className="text-gray-700 mt-4 text-center">
                {codeExamples.find(e => e.name === currentExample)?.desc}
              </p>
            </div>
          </section>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/04-css-01" className="font-medium hover:text-green-600 transition-colors">
                CSS动画关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">6</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/05-news01" className="font-medium hover:text-green-600 transition-colors">
                新闻列表关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-yellow-600 border-yellow-800 hover:bg-yellow-700">
              💻 完成关卡，掌握JavaScript基础！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 