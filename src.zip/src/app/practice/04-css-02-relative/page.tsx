'use client';
import Link from 'next/link';

export default function JavaScriptAdvancedLevel() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-green-400 to-blue-500 py-8 px-2 relative overflow-hidden">
      {/* 马里奥背景装饰 */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-0">
        <div className="absolute top-20 left-10 w-16 h-12 bg-orange-600 border-2 border-orange-800 rounded-sm mario-brick"></div>
        <div className="absolute top-1/3 right-20 w-8 h-8 bg-yellow-400 border-2 border-yellow-600 rounded-full mario-coin"></div>
        <div className="absolute bottom-0 left-20 w-12 h-24 bg-green-600 border-4 border-green-800 rounded-t-lg"></div>
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="mb-8">
          <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
        </div>
        
        <header className="text-center mb-16">
          <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">7</div>
          <h1 className="text-4xl md:text-5xl font-black mario-text-gradient mb-4 tracking-widest drop-shadow">🚀 JavaScript进阶关卡</h1>
          <p className="text-lg text-gray-800 max-w-3xl mx-auto">
            深入JavaScript高级特性，就像马里奥掌握各种特殊技能一样！
          </p>
        </header>
        
        <div className="grid md:grid-cols-2 gap-8 items-start">
          {/* Section: 基础JavaScript */}
          <section className="mario-section p-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">基础JavaScript结构</h2>
            <div className="space-y-4 text-gray-800 text-center">
              <div className="mario-card p-4 relative">
                <span className="text-2xl">📦</span>
                <p className="text-sm mt-1 font-medium">变量声明</p>
                <code className="text-xs bg-blue-100 px-2 py-1 rounded mt-1 block">let mario = "hero";</code>
              </div>
              <div className="mario-card p-4 relative">
                <span className="text-2xl">⚡</span>
                <p className="text-sm mt-1 font-medium">函数定义</p>
                <code className="text-xs bg-green-100 px-2 py-1 rounded mt-1 block">function jump() {`{ ... }`}</code>
              </div>
              <div className="mario-card p-4 bg-yellow-100 border-yellow-500 relative">
                <span className="text-2xl">🎯</span>
                <p className="text-sm mt-1 font-medium">ES6+ 特性 (高级技能)</p>
                <code className="text-xs bg-yellow-200 px-2 py-1 rounded mt-1 block">const arrow = () =&gt; {`{ ... }`}</code>
              </div>
              <div className="mario-card p-4 relative">
                <span className="text-2xl">🔄</span>
                <p className="text-sm mt-1 font-medium">异步编程</p>
                <code className="text-xs bg-purple-100 px-2 py-1 rounded mt-1 block">async/await</code>
              </div>
            </div>
          </section>
          
          {/* Section: ES6+ 高级特性 */}
          <section className="mario-section p-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">ES6+ 高级特性</h2>
            <div className="space-y-4 text-gray-800 text-center relative">
              <div className="mario-card p-4 relative">
                <span className="text-2xl">📦</span>
                <p className="text-sm mt-1 font-medium">解构赋值</p>
                <code className="text-xs bg-blue-100 px-2 py-1 rounded mt-1 block">const {`{x, y}`} = mario;</code>
              </div>
              <div className="mario-card p-4 relative">
                <span className="text-2xl">🔥</span>
                <p className="text-sm mt-1 font-medium">模板字符串</p>
                <code className="text-xs bg-green-100 px-2 py-1 rounded mt-1 block">{"`马里奥得分：${score}`"}</code>
              </div>
              {/* 虚影：原始位置 */}
              <div className="mario-card p-4 bg-gray-100 border-dashed border-gray-400 text-gray-400 relative">
                <span className="text-2xl opacity-50">👻</span>
                <p className="text-sm mt-1">箭头函数的原始位置</p>
              </div>
              {/* 进阶特性：相对定位效果 */}
              <div className="mario-card p-4 bg-red-500 text-white absolute w-full transform translate-x-10 shadow-xl hover:scale-105 transition-transform cursor-pointer" 
                   style={{ top: 'calc(8rem + 2rem + 8px)' }}
                   onClick={() => alert('ES6箭头函数：更简洁的函数语法！\n\nconst jump = () => console.log("马里奥跳跃！");\n\n特点：\n- 语法更简洁\n- 自动绑定this\n- 适合回调函数')}>
                <span className="text-2xl animate-bounce">🏹</span>
                <p className="text-sm mt-1 font-semibold">箭头函数 (高级语法)</p>
                <code className="text-xs bg-red-400 px-2 py-1 rounded mt-1 block">const jump = () =&gt; &quot;Super!&quot;</code>
              </div>
              <div className="mario-card p-4 relative">
                <span className="text-2xl">🔮</span>
                <p className="text-sm mt-1 font-medium">Promise/Async</p>
                <code className="text-xs bg-purple-100 px-2 py-1 rounded mt-1 block">await loadLevel();</code>
              </div>
              <p className="text-sm text-blue-600 pt-16 text-center mario-card p-3 mt-8">
                💡 进阶技巧：箭头函数虽然位置发生了变化，但不影响其他代码的布局，
                这体现了JavaScript的灵活性，就像马里奥的高级技能一样强大！
              </p>
            </div>
          </section>
        </div>

        {/* ES6+ 特性详解 */}
        <div className="mt-12 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
          <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🚀 JavaScript高级技能树</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="mario-card p-6 hover:shadow-lg transition-shadow cursor-pointer"
                 onClick={() => alert('箭头函数：ES6引入的新语法\n\n// 传统函数\nfunction jump() {\n  return "马里奥跳跃！";\n}\n\n// 箭头函数\nconst jump = () => "马里奥跳跃！";\n\n更简洁，this绑定更清晰！')}>
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center">
                <span className="text-2xl text-white">🏹</span>
              </div>
              <h3 className="font-bold text-red-700 mb-2">箭头函数</h3>
              <p className="text-red-600 text-sm">简洁的函数语法</p>
              <code className="text-xs bg-red-100 px-2 py-1 rounded mt-2 block">() =&gt; {`{}`}</code>
            </div>
            
            <div className="mario-card p-6 hover:shadow-lg transition-shadow cursor-pointer"
                 onClick={() => alert('解构赋值：快速提取对象属性\n\nconst mario = { x: 100, y: 200, speed: 5 };\n\n// 解构赋值\nconst { x, y, speed } = mario;\n\nconsole.log(x); // 100\nconsole.log(y); // 200\n\n让代码更简洁！')}>
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
                <span className="text-2xl text-white">📦</span>
              </div>
              <h3 className="font-bold text-green-700 mb-2">解构赋值</h3>
              <p className="text-green-600 text-sm">快速提取数据</p>
              <code className="text-xs bg-green-100 px-2 py-1 rounded mt-2 block">{`const {x, y} = mario;`}</code>
            </div>
            
            <div className="mario-card p-6 hover:shadow-lg transition-shadow cursor-pointer"
                 onClick={() => alert('异步编程：处理耗时操作\n\n// Promise\nfetch("api/mario")\n  .then(data => console.log(data));\n\n// Async/Await\nasync function loadMario() {\n  const data = await fetch("api/mario");\n  return data.json();\n}\n\n让程序不卡顿！')}>
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                <span className="text-2xl text-white">⚡</span>
              </div>
              <h3 className="font-bold text-blue-700 mb-2">异步编程</h3>
              <p className="text-blue-600 text-sm">处理异步操作</p>
              <code className="text-xs bg-blue-100 px-2 py-1 rounded mt-2 block">async/await</code>
            </div>
          </div>
        </div>

        {/* 代码示例区域 */}
        <div className="mt-8 mario-section p-6 bg-gray-900/90">
          <h3 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 马里奥高级技能代码实战</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-bold text-green-400">🏹 箭头函数示例</h4>
              <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                <div className="text-blue-400">{/* ES6箭头函数 */}</div>
                <div className="text-green-400">const moveMario = (direction) =&gt; {`{`}</div>
                <div className="ml-4 text-yellow-400">if (direction === 'right') {`{`}</div>
                <div className="ml-8 text-white">mario.x += mario.speed;</div>
                <div className="ml-4 text-yellow-400">{`}`}</div>
                <div className="text-green-400">{`}`};</div>
                <div className="mt-2 text-purple-400">moveMario('right');</div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-bold text-blue-400">📦 解构赋值示例</h4>
              <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                <div className="text-blue-400">{/* 对象解构 */}</div>
                <div className="text-green-400">const gameState = {`{`}</div>
                <div className="ml-4 text-yellow-400">score: 1500,</div>
                <div className="ml-4 text-yellow-400">lives: 3,</div>
                <div className="ml-4 text-yellow-400">level: 2</div>
                <div className="text-green-400">{`}`};</div>
                <div className="mt-2 text-purple-400">const {`{score, lives}`} = gameState;</div>
              </div>
            </div>
          </div>
        </div>

        {/* 关卡导航 */}
        <div className="flex justify-between items-center mt-12 mario-section p-6">
          <div className="text-gray-700">
            <span className="text-sm">上一关：</span>
            <Link href="/practice/04-css-02" className="font-medium hover:text-green-600 transition-colors">
              JavaScript基础关卡
            </Link>
          </div>
          
          <div className="text-center">
            <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">7</div>
            <p className="text-sm text-gray-600">当前关卡</p>
          </div>
          
          <div className="text-gray-700 text-right">
            <span className="text-sm">下一关：</span>
            <Link href="/practice/05-news01" className="font-medium hover:text-green-600 transition-colors">
              DOM操作关卡
            </Link>
          </div>
        </div>

        {/* 完成按钮 */}
        <div className="text-center mt-8">
          <button className="mario-button px-12 py-4 text-lg font-bold bg-blue-600 border-blue-800 hover:bg-blue-700 power-up-glow">
            🚀 完成关卡，掌握JavaScript高级技能！
          </button>
        </div>
      </div>
    </div>
  );
} 