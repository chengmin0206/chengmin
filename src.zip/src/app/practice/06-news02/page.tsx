'use client';
import { useState } from 'react';
import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function ReactBasicLevel() {
  const [marioState, setMarioState] = useState('small');
  const [coins, setCoins] = useState(0);
  const [lives, setLives] = useState(3);
  const [selectedComponent, setSelectedComponent] = useState('');

  const powerUp = () => {
    if (marioState === 'small') {
      setMarioState('super');
    } else if (marioState === 'super') { 
      setMarioState('fire');
    } else {
      setMarioState('small');
    }
  };

  const collectCoin = () => {
    setCoins(coins + 1);
    if (coins + 1 >= 100) {
      setLives(lives + 1);
      setCoins(0);
    }
  };

  const loseLife = () => {
    if (lives > 1) {
      setLives(lives - 1);
      setMarioState('small');
    } else {
      alert('游戏结束！马里奥需要重新开始React冒险！');
      setLives(3);
      setCoins(0);
      setMarioState('small');
    }
  };

  const reactConcepts = [
    { 
      name: '组件', 
      icon: '🧩', 
      desc: 'React的基本构建块', 
      code: 'function MarioComponent() { return <div>🍄</div>; }',
      color: 'from-red-400 to-red-600'
    },
    { 
      name: 'JSX', 
      icon: '📝', 
      desc: 'JavaScript + XML语法', 
      code: 'const mario = <div className="mario">🍄</div>;',
      color: 'from-green-400 to-green-600'
    },
    { 
      name: 'Props', 
      icon: '📦', 
      desc: '组件间数据传递', 
      code: 'function Mario({ size, color }) { ... }',
      color: 'from-blue-400 to-blue-600'
    },
    { 
      name: 'State', 
      icon: '🎛️', 
      desc: '组件内部状态', 
      code: 'const [coins, setCoins] = useState(0);',
      color: 'from-purple-400 to-purple-600'
    },
    { 
      name: 'Events', 
      icon: '⚡', 
      desc: '用户交互处理', 
      code: 'onClick={() => jumpMario()}',
      color: 'from-yellow-400 to-yellow-600'
    }
  ];

  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">10</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-6 tracking-widest drop-shadow">⚛️ React基础关卡</h1>
            <p className="text-lg text-gray-800 mb-6">进入React的世界，像马里奥进入新世界一样开始组件化开发！</p>
          </div>

          {/* 马里奥状态演示区 */}
          <section className="mb-8 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🎮 React State 状态管理演示</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="mario-card p-6 text-center">
                <h3 className="text-xl font-bold text-red-700 mb-4">马里奥状态</h3>
                <div className="text-6xl mb-4">
                  {marioState === 'small' ? '🍄' : 
                   marioState === 'super' ? '🦸‍♂️' : '🔥'}
                </div>
                <p className="text-gray-700 mb-4">当前状态: {marioState}</p>
                <button onClick={powerUp} className="mario-button px-4 py-2 text-sm">
                  🌟 变身
                </button>
              </div>
              
              <div className="mario-card p-6 text-center">
                <h3 className="text-xl font-bold text-yellow-700 mb-4">金币收集</h3>
                <div className="text-4xl mb-2">🪙 × {coins}</div>
                <p className="text-gray-700 mb-4">收集100个金币获得额外生命！</p>
                <button onClick={collectCoin} className="mario-button px-4 py-2 text-sm bg-yellow-600 border-yellow-800">
                  💰 收集金币
                </button>
              </div>
              
              <div className="mario-card p-6 text-center">
                <h3 className="text-xl font-bold text-green-700 mb-4">生命值</h3>
                <div className="text-4xl mb-2">❤️ × {lives}</div>
                <p className="text-gray-700 mb-4">小心敌人攻击！</p>
                <button onClick={loseLife} className="mario-button px-4 py-2 text-sm bg-red-600 border-red-800">
                  💀 失去生命
                </button>
              </div>
            </div>
          </section>

          {/* React核心概念展示 */}
          <section className="mb-8 mario-section p-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">⚛️ React核心概念</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              {reactConcepts.map((concept, index) => (
                <div
                  key={index}
                  className={`text-center p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedComponent === concept.name 
                      ? 'bg-red-500 text-white shadow-lg mario-glow' 
                      : 'mario-card hover:bg-blue-50 text-gray-700'
                  }`}
                  onClick={() => setSelectedComponent(selectedComponent === concept.name ? '' : concept.name)}
                >
                  <div className={`w-16 h-16 mx-auto mb-2 bg-gradient-to-br ${concept.color} rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-all duration-500`}>
                    <span className="text-2xl filter drop-shadow-sm">{concept.icon}</span>
                  </div>
                  <h3 className="font-bold text-sm mb-1">{concept.name}</h3>
                  <p className="text-xs opacity-80">{concept.desc}</p>
                </div>
              ))}
            </div>
            
            {selectedComponent && (
              <div className="mario-card p-6 border-l-4 border-red-500">
                <h4 className="font-bold text-red-700 mb-3">{selectedComponent} 详解</h4>
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm mb-4">
                  <code className="text-green-400">
                    {reactConcepts.find(c => c.name === selectedComponent)?.code}
                  </code>
                </div>
                <p className="text-gray-700 text-sm">
                  {reactConcepts.find(c => c.name === selectedComponent)?.desc}，
                  是React开发的重要概念，就像马里奥游戏中的基本元素一样重要！
                </p>
              </div>
            )}
          </section>

          {/* 代码示例展示 */}
          <section className="mb-8 mario-section p-6 bg-gray-900/90">
            <h2 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 马里奥React代码实战</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold text-green-400">🧩 React组件定义</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 马里奥组件 */}</div>
                  <div className="text-green-400">function Mario({`{ size, coins }`}) {`{`}</div>
                  <div className="ml-4 text-yellow-400">const [isJumping, setIsJumping] = useState(false);</div>
                  <div className="ml-4 text-white">return (</div>
                  <div className="ml-8 text-purple-400">&lt;div className=&quot;mario&quot;&gt;</div>
                  <div className="ml-12 text-cyan-400">{`{size === 'super' ? '🦸‍♂️' : '🍄'}`}</div>
                  <div className="ml-12 text-orange-400">&lt;span&gt;金币: {`{coins}`}&lt;/span&gt;</div>
                  <div className="ml-8 text-purple-400">&lt;/div&gt;</div>
                  <div className="ml-4 text-white">);</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-bold text-blue-400">🎛️ React Hook状态管理</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* useState Hook */}</div>
                  <div className="text-green-400">const [marioState, setMarioState] = useState(&apos;small&apos;);</div>
                  <div className="text-green-400">const [coins, setCoins] = useState(0);</div>
                  <div className="text-green-400">const [lives, setLives] = useState(3);</div>
                  <div className="text-yellow-400 mt-2">{/* 状态更新函数 */}</div>
                  <div className="text-purple-400">const powerUp = () =&gt; {`{`}</div>
                  <div className="ml-4 text-white">setMarioState(&apos;super&apos;);</div>
                  <div className="text-purple-400">{`}`};</div>
                </div>
              </div>
            </div>
          </section>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/06-news01" className="font-medium hover:text-green-600 transition-colors">
                异步编程关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">10</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/07-async-01" className="font-medium hover:text-green-600 transition-colors">
                React进阶关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-blue-600 border-blue-800 hover:bg-blue-700">
              ⚛️ 完成关卡，掌握React基础！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 