export default function MyAppDemo() {
  return (
    <div style={{ border: '1px solid #16a34a', padding: '15px', margin: '10px', borderRadius: '8px', backgroundColor: '#f0fdf4' }}>
      <h2 style={{ color: '#16a34a', marginBottom: '10px' }}>马里奥冒险关卡流程</h2>
      <p style={{ color: '#166534' }}>1-1关 → 1-2关 → 1-3关 → 1-4城堡 → 2-1关 → 2-2关 → 2-3关 → 2-4城堡</p>
      <p style={{ fontSize: '14px', color: '#15803d', marginTop: '8px' }}>
        超级马里奥是任天堂最经典的游戏系列之一，让我们开始编程冒险吧！
      </p>
    </div>
  );
} 