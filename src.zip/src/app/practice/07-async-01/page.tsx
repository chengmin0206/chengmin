'use client';
import { useState, useEffect, useCallback, useMemo } from 'react';
import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function ReactHooksLevel() {
  const [marioLevel, setMarioLevel] = useState(1);
  const [experience, setExperience] = useState(0);
  const [powerUps, setPowerUps] = useState<string[]>([]);
  const [gameTime, setGameTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedHook, setSelectedHook] = useState('');

  // useEffect Hook - 游戏计时器
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setGameTime(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying]);

  // useEffect Hook - 自动升级检查
  useEffect(() => {
    if (experience >= marioLevel * 100) {
      setMarioLevel(prev => prev + 1);
      setExperience(0);
      console.log(`🎉 马里奥升级到第${marioLevel + 1}级！`);
    }
  }, [experience, marioLevel]);

  // useCallback Hook - 优化函数性能
  const addExperience = useCallback((amount: number) => {
    setExperience(prev => prev + amount);
    console.log(`马里奥获得${amount}点经验值！`);
  }, []);

  const collectPowerUp = useCallback((powerUp: string) => {
    setPowerUps(prev => [...prev, powerUp]);
    addExperience(50);
  }, [addExperience]);

  // useMemo Hook - 计算马里奥状态
  const marioStatus = useMemo(() => {
    return {
      title: marioLevel >= 10 ? '传奇马里奥' : 
             marioLevel >= 5 ? '超级马里奥' : '新手马里奥',
      emoji: marioLevel >= 10 ? '👑' :
             marioLevel >= 5 ? '🦸‍♂️' : '🍄',
      color: marioLevel >= 10 ? 'from-yellow-400 to-orange-600' :
             marioLevel >= 5 ? 'from-blue-400 to-purple-600' : 'from-red-400 to-red-600'
    };
  }, [marioLevel]);

  const reactHooks = [
    {
      name: 'useState',
      icon: '🎛️',
      desc: '管理组件状态',
      code: 'const [count, setCount] = useState(0);',
      color: 'from-red-400 to-red-600',
      example: '控制马里奥的生命值、金币数量等游戏状态'
    },
    {
      name: 'useEffect',
      icon: '⚡',
      desc: '处理副作用',
      code: 'useEffect(() => { /* 副作用逻辑 */ }, []);',
      color: 'from-green-400 to-green-600',
      example: '游戏计时器、自动保存、API数据获取'
    },
    {
      name: 'useCallback',
      icon: '🔄',
      desc: '优化函数性能',
      code: 'const memoizedCallback = useCallback(() => {}, []);',
      color: 'from-blue-400 to-blue-600',
      example: '优化马里奥跳跃、攻击等频繁调用的函数'
    },
    {
      name: 'useMemo',
      icon: '🧠',
      desc: '优化计算性能',
      code: 'const memoizedValue = useMemo(() => compute(), []);',
      color: 'from-purple-400 to-purple-600',
      example: '计算复杂的游戏得分、排行榜等数据'
    },
    {
      name: 'useContext',
      icon: '🌐',
      desc: '共享全局状态',
      code: 'const value = useContext(MyContext);',
      color: 'from-yellow-400 to-yellow-600',
      example: '游戏全局设置、用户信息、主题切换'
    }
  ];

  const toggleGame = () => {
    setIsPlaying(!isPlaying);
    if (!isPlaying) {
      console.log('🎮 马里奥冒险开始！');
    } else {
      console.log('⏸️ 游戏已暂停');
    }
  };

  const resetGame = () => {
    setMarioLevel(1);
    setExperience(0);
    setPowerUps([]);
    setGameTime(0);
    setIsPlaying(false);
    console.log('🔄 游戏已重置');
  };

  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">11</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-6 tracking-widest drop-shadow">🪝 React Hooks关卡</h1>
            <p className="text-lg text-gray-800 mb-6">掌握React Hooks，让马里奥获得新道具一样强大！</p>
          </div>

          {/* 马里奥游戏状态面板 */}
          <section className="mb-8 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🎮 React Hooks 游戏状态演示</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div className="mario-card p-6 text-center">
                <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-br ${marioStatus.color} rounded-full flex items-center justify-center`}>
                  <span className="text-2xl">{marioStatus.emoji}</span>
                </div>
                <h3 className="text-lg font-bold text-red-700 mb-2">等级 {marioLevel}</h3>
                <p className="text-gray-700 text-sm">{marioStatus.title}</p>
              </div>
              
              <div className="mario-card p-6 text-center">
                <div className="text-3xl mb-2">⚡</div>
                <h3 className="text-lg font-bold text-blue-700 mb-2">经验值</h3>
                <p className="text-gray-700">{experience} / {marioLevel * 100}</p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(experience / (marioLevel * 100)) * 100}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="mario-card p-6 text-center">
                <div className="text-3xl mb-2">⏱️</div>
                <h3 className="text-lg font-bold text-green-700 mb-2">游戏时间</h3>
                <p className="text-gray-700">{Math.floor(gameTime / 60)}:{(gameTime % 60).toString().padStart(2, '0')}</p>
                <p className="text-sm text-gray-500">{isPlaying ? '游戏中' : '已暂停'}</p>
              </div>
              
              <div className="mario-card p-6 text-center">
                <div className="text-3xl mb-2">🎁</div>
                <h3 className="text-lg font-bold text-purple-700 mb-2">道具收集</h3>
                <p className="text-gray-700">{powerUps.length} 个道具</p>
                <div className="flex justify-center gap-1 mt-2">
                  {powerUps.slice(-3).map((powerUp, index) => (
                    <span key={index} className="text-lg">{powerUp}</span>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex justify-center gap-4">
              <button onClick={toggleGame} className={`mario-button px-6 py-3 ${isPlaying ? 'bg-orange-600 border-orange-800' : 'bg-green-600 border-green-800'}`}>
                {isPlaying ? '⏸️ 暂停游戏' : '▶️ 开始游戏'}
              </button>
              <button onClick={() => addExperience(25)} className="mario-button px-6 py-3 bg-blue-600 border-blue-800">
                ⭐ 获得经验
              </button>
              <button onClick={() => collectPowerUp(['🍄', '⭐', '🌟', '🔥'][Math.floor(Math.random() * 4)])} className="mario-button px-6 py-3 bg-purple-600 border-purple-800">
                🎁 收集道具
              </button>
              <button onClick={resetGame} className="mario-button px-6 py-3 bg-red-600 border-red-800">
                🔄 重置游戏
              </button>
            </div>
          </section>

          {/* React Hooks知识展示 */}
          <section className="mb-8 mario-section p-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🪝 React Hooks 核心知识</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              {reactHooks.map((hook, index) => (
                <div
                  key={index}
                  className={`text-center p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedHook === hook.name 
                      ? 'bg-red-500 text-white shadow-lg mario-glow' 
                      : 'mario-card hover:bg-blue-50 text-gray-700'
                  }`}
                  onClick={() => setSelectedHook(selectedHook === hook.name ? '' : hook.name)}
                >
                  <div className={`w-16 h-16 mx-auto mb-2 bg-gradient-to-br ${hook.color} rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-all duration-500`}>
                    <span className="text-2xl filter drop-shadow-sm">{hook.icon}</span>
                  </div>
                  <h3 className="font-bold text-sm mb-1">{hook.name}</h3>
                  <p className="text-xs opacity-80">{hook.desc}</p>
                </div>
              ))}
            </div>
            
            {selectedHook && (
              <div className="mario-card p-6 border-l-4 border-red-500">
                <h4 className="font-bold text-red-700 mb-3">{selectedHook} 详解</h4>
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm mb-4">
                  <code className="text-green-400">
                    {reactHooks.find(h => h.name === selectedHook)?.code}
                  </code>
                </div>
                <p className="text-gray-700 text-sm">
                  {reactHooks.find(h => h.name === selectedHook)?.example}
                </p>
              </div>
            )}
          </section>

          {/* 代码示例展示 */}
          <section className="mb-8 mario-section p-6 bg-gray-900/90">
            <h2 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 马里奥React Hooks实战</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold text-green-400">⚡ useEffect Hook</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 游戏计时器 */}</div>
                  <div className="text-green-400">useEffect(() =&gt; {`{`}</div>
                  <div className="ml-4 text-yellow-400">let timer;</div>
                  <div className="ml-4 text-white">if (isPlaying) {`{`}</div>
                  <div className="ml-8 text-purple-400">timer = setInterval(() =&gt; {`{`}</div>
                  <div className="ml-12 text-cyan-400">setGameTime(prev =&gt; prev + 1);</div>
                  <div className="ml-8 text-purple-400">{`}`}, 1000);</div>
                  <div className="ml-4 text-white">{`}`}</div>
                  <div className="ml-4 text-yellow-400">return () =&gt; clearInterval(timer);</div>
                  <div className="text-green-400">{`}`}, [isPlaying]);</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-bold text-blue-400">🧠 useMemo Hook</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 马里奥状态计算 */}</div>
                  <div className="text-green-400">const marioStatus = useMemo(() =&gt; {`{`}</div>
                  <div className="ml-4 text-yellow-400">return {`{`}</div>
                  <div className="ml-8 text-white">title: level &gt;= 10 ? &apos;传奇&apos; : &apos;新手&apos;,</div>
                  <div className="ml-8 text-white">emoji: level &gt;= 10 ? &apos;👑&apos; : &apos;🍄&apos;</div>
                  <div className="ml-4 text-yellow-400">{`}`};</div>
                  <div className="text-green-400">{`}`}, [level]);</div>
                </div>
              </div>
            </div>
          </section>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/06-news02" className="font-medium hover:text-green-600 transition-colors">
                React基础关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">11</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/07-async-02" className="font-medium hover:text-green-600 transition-colors">
                React进阶关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-purple-600 border-purple-800 hover:bg-purple-700">
              🪝 完成关卡，掌握React Hooks！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 