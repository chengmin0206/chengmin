'use client';
import { useEffect } from 'react';
import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function AsyncProgrammingLevel() {
  useEffect(() => {
    // 异步编程相关的JavaScript演示
    console.log("=== 马里奥的异步冒险开始！ ===");
    
    // Promise基础演示
    console.log("\n🎯 Promise异步处理：");
    const collectCoin = new Promise((resolve, reject) => {
      setTimeout(() => {
        const success = Math.random() > 0.2;
        if (success) {
          resolve("马里奥成功收集到金币！");
        } else {
          reject("金币被敌人抢走了！");
        }
      }, 1000);
    });
    
    collectCoin
      .then(message => console.log("✅", message))
      .catch(error => console.log("❌", error));
    
    // Async/Await演示
    async function marioJumpSequence() {
      console.log("\n🚀 马里奥连续跳跃序列：");
      try {
        console.log("准备跳跃...");
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log("第一次跳跃完成！");
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log("第二次跳跃完成！");
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log("完美着陆！马里奥获得额外分数！");
      } catch (error) {
        console.log("跳跃失败：", error);
      }
    }
    
    marioJumpSequence();
    
    // 定时器演示
    console.log("\n⏰ 游戏定时器：");
    let gameTime = 0;
    const gameTimer = setInterval(() => {
      gameTime += 1;
      console.log(`游戏时间：${gameTime}秒`);
      if (gameTime >= 5) {
        clearInterval(gameTimer);
        console.log("⏱️ 本轮游戏结束！");
      }
    }, 1000);
    
    console.log("\n🎮 异步编程让马里奥的世界更加生动！");
  }, []);

  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">9</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-6 tracking-widest drop-shadow">⚡ 异步编程关卡</h1>
            <p className="text-lg text-gray-800 mb-6">掌握异步编程，让马里奥同时处理多个任务！</p>
          </div>
          
          <section className="mb-8 mario-section p-6">
            <h2 className="text-2xl font-black mario-text-gradient mb-4">🎯 异步编程体验说明</h2>
            <ul className="list-disc list-inside text-gray-700 space-y-2">
              <li>本关卡通过马里奥游戏场景展示异步编程的核心概念。</li>
              <li>页面加载后会在控制台演示Promise、Async/Await等异步技术。</li>
              <li>请按 F12 打开浏览器控制台，观察马里奥的异步冒险！</li>
            </ul>
          </section>

          {/* 异步编程概念展示 */}
          <section className="mb-8 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🚀 异步编程核心技能</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[
                { skill: 'Promise', icon: '🎯', desc: '异步承诺', color: 'from-red-400 to-orange-400', example: 'new Promise()' },
                { skill: 'Async/Await', icon: '⚡', desc: '异步等待', color: 'from-green-400 to-emerald-400', example: 'async/await' },
                { skill: 'setTimeout', icon: '⏰', desc: '延时执行', color: 'from-blue-400 to-cyan-400', example: 'setTimeout()' },
                { skill: 'setInterval', icon: '🔄', desc: '定时重复', color: 'from-purple-400 to-indigo-400', example: 'setInterval()' }
              ].map((item, index) => (
                <div key={index} className="text-center group">
                  <div className={`w-16 h-16 mx-auto mb-2 bg-gradient-to-br ${item.color} rounded-full flex items-center justify-center shadow-lg border-2 border-white hover:scale-110 transition-all duration-300 cursor-pointer group-hover:animate-bounce`}
                       onClick={() => alert(`${item.skill}：${item.desc}\n\n${item.example}\n\n这是异步编程的核心技能，让马里奥能够同时处理多个游戏任务！`)}>
                    <span className="text-2xl filter drop-shadow-sm">{item.icon}</span>
                  </div>
                  <h3 className="font-bold text-gray-700 mb-1 text-sm">{item.skill}</h3>
                  <p className="text-xs text-gray-600">{item.desc}</p>
                  <code className="text-xs bg-gray-100 px-2 py-1 rounded mt-1 block">{item.example}</code>
                </div>
              ))}
            </div>
          </section>

          {/* 代码示例展示 */}
          <section className="mb-8 mario-section p-6 bg-gray-900/90">
            <h2 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 马里奥异步编程实战</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold text-green-400">🎯 Promise异步处理</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 马里奥收集金币Promise */}</div>
                  <div className="text-green-400">const collectCoin = new Promise((resolve, reject) =&gt; {`{`}</div>
                  <div className="ml-4 text-yellow-400">setTimeout(() =&gt; {`{`}</div>
                  <div className="ml-8 text-white">if (Math.random() &gt; 0.5) {`{`}</div>
                  <div className="ml-12 text-purple-400">resolve(&apos;收集成功！&apos;);</div>
                  <div className="ml-8 text-white">{`}`} else {`{`}</div>
                  <div className="ml-12 text-red-400">reject(&apos;收集失败！&apos;);</div>
                  <div className="ml-8 text-white">{`}`}</div>
                  <div className="ml-4 text-yellow-400">{`}`}, 1000);</div>
                  <div className="text-green-400">{`}`});</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-bold text-blue-400">⚡ Async/Await语法</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 马里奥跳跃序列 */}</div>
                  <div className="text-green-400">async function marioJump() {`{`}</div>
                  <div className="ml-4 text-yellow-400">try {`{`}</div>
                  <div className="ml-8 text-white">await jump1();</div>
                  <div className="ml-8 text-white">await jump2();</div>
                  <div className="ml-8 text-purple-400">console.log("完美连跳！");</div>
                  <div className="ml-4 text-yellow-400">{`}`} catch (error) {`{`}</div>
                  <div className="ml-8 text-red-400">console.log("跳跃失败！");</div>
                  <div className="ml-4 text-yellow-400">{`}`}</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
              </div>
            </div>
          </section>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/05-news01" className="font-medium hover:text-green-600 transition-colors">
                DOM操作关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">9</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/06-news02" className="font-medium hover:text-green-600 transition-colors">
                React基础关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-purple-600 border-purple-800 hover:bg-purple-700">
              ⚡ 完成关卡，掌握异步编程！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 