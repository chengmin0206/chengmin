'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function NextJsFullStackLevel() {
  const [deploymentStatus, setDeploymentStatus] = useState('ready');
  const [buildProgress, setBuildProgress] = useState(0);
  const [selectedFeature, setSelectedFeature] = useState('');
  const [congratsVisible, setCongratulationsVisible] = useState(false);

  // 模拟部署过程
  const deployMarioApp = async () => {
    setDeploymentStatus('building');
    setBuildProgress(0);
    
    const steps = [
      '🏗️ 初始化Next.js项目',
      '⚛️ 编译React组件',
      '🎨 优化Tailwind CSS',
      '📦 打包应用资源',
      '🚀 部署到服务器',
      '✅ 部署完成！'
    ];
    
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setBuildProgress((i + 1) / steps.length * 100);
      console.log(steps[i]);
    }
    
    setDeploymentStatus('deployed');
    setCongratulationsVisible(true);
    console.log('🎉 马里奥的Next.js应用部署成功！');
  };

  const resetDeployment = () => {
    setDeploymentStatus('ready');
    setBuildProgress(0);
    setCongratulationsVisible(false);
  };

  const nextjsFeatures = [
    {
      name: 'SSR/SSG',
      icon: '🏗️',
      desc: '服务端渲染',
      detail: 'Server-Side Rendering 和 Static Site Generation，提升SEO和首屏加载速度',
      code: 'export async function getServerSideProps() { ... }',
      color: 'from-blue-400 to-blue-600'
    },
    {
      name: 'API Routes',
      icon: '🛣️',
      desc: 'API路由系统',
      detail: '在Next.js中创建后端API接口，实现全栈开发',
      code: 'export default function handler(req, res) { ... }',
      color: 'from-green-400 to-green-600'
    },
    {
      name: 'Dynamic Routes',
      icon: '🔀',
      desc: '动态路由',
      detail: '基于文件系统的路由，支持动态参数和嵌套路由',
      code: 'pages/mario/[id].js → /mario/123',
      color: 'from-purple-400 to-purple-600'
    },
    {
      name: 'Image Optimization',
      icon: '🖼️',
      desc: '图片优化',
      detail: '自动图片优化、懒加载和WebP格式转换',
      code: '<Image src="/mario.png" width={100} height={100} />',
      color: 'from-red-400 to-red-600'
    },
    {
      name: 'Middleware',
      icon: '🔧',
      desc: '中间件',
      detail: '在请求完成之前运行代码，实现身份验证、重定向等',
      code: 'export function middleware(request) { ... }',
      color: 'from-yellow-400 to-yellow-600'
    }
  ];

  const techStack = [
    { name: 'Next.js 14', icon: '⚡', desc: 'React全栈框架' },
    { name: 'React 19', icon: '⚛️', desc: '用户界面库' },
    { name: 'TypeScript', icon: '🔷', desc: '类型安全' },
    { name: 'Tailwind CSS', icon: '🎨', desc: '原子化CSS' },
    { name: 'Vercel', icon: '🚀', desc: '部署平台' }
  ];

  useEffect(() => {
    console.log('🏰 欢迎来到最终Boss关卡 - Next.js全栈开发！');
    console.log('🎯 在这里，马里奥将掌握完整的全栈开发技能！');
  }, []);

  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        {congratsVisible && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="mario-section p-8 max-w-lg mx-auto text-center animate-bounce">
              <div className="text-6xl mb-4">🎉</div>
              <h2 className="text-3xl font-black mario-text-gradient mb-4">恭喜通关！</h2>
              <p className="text-gray-700 mb-6">马里奥已经掌握了Next.js全栈开发技能，成为了真正的编程英雄！</p>
              <button onClick={() => setCongratulationsVisible(false)} className="mario-button px-6 py-3">
                继续冒险 🚀
              </button>
            </div>
          </div>
        )}

        <div className="max-w-5xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8 relative">
            <div className="boss-badge mx-auto mb-4 w-20 h-20 text-2xl font-black">12</div>
            <h1 className="text-4xl md:text-5xl font-black mario-text-gradient mb-4 tracking-widest drop-shadow">
              👑 Next.js全栈关卡
            </h1>
            <p className="text-xl text-gray-800 mb-4">最终挑战！掌握Next.js全栈开发，像马里奥拯救公主一样完成项目！</p>
            <div className="inline-block bg-red-600 text-white px-4 py-2 rounded-full text-sm font-bold animate-pulse">
              🏰 BOSS关卡
            </div>
          </div>

          {/* 项目部署演示区 */}
          <section className="mb-8 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🚀 Next.js 应用部署演示</h2>
            
            <div className="mario-card p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-blue-700">马里奥的Next.js应用</h3>
                <div className={`px-3 py-1 rounded-full text-sm font-bold ${
                  deploymentStatus === 'ready' ? 'bg-gray-200 text-gray-700' :
                  deploymentStatus === 'building' ? 'bg-yellow-200 text-yellow-700' :
                  'bg-green-200 text-green-700'
                }`}>
                  {deploymentStatus === 'ready' ? '准备部署' :
                   deploymentStatus === 'building' ? '构建中...' : '已部署'}
                </div>
              </div>
              
              {deploymentStatus === 'building' && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>构建进度</span>
                    <span>{Math.round(buildProgress)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="bg-gradient-to-r from-green-400 to-blue-500 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${buildProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}
              
              <div className="flex gap-4">
                <button 
                  onClick={deployMarioApp}
                  disabled={deploymentStatus === 'building'}
                  className={`mario-button px-6 py-3 ${
                    deploymentStatus === 'building' ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {deploymentStatus === 'building' ? '部署中...' : '🚀 部署应用'}
                </button>
                
                {deploymentStatus === 'deployed' && (
                  <button onClick={resetDeployment} className="mario-button px-6 py-3 bg-gray-600 border-gray-800">
                    🔄 重新部署
                  </button>
                )}
                
                {deploymentStatus === 'deployed' && (
                  <a 
                    href="#" 
                    onClick={(e) => {e.preventDefault(); alert('🎉 应用访问地址：https://mario-nextjs-app.vercel.app')}}
                    className="mario-button px-6 py-3 bg-green-600 border-green-800"
                  >
                    🌐 访问应用
                  </a>
                )}
              </div>
            </div>
          </section>

          {/* Next.js功能特性展示 */}
          <section className="mb-8 mario-section p-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">⚡ Next.js 核心功能</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              {nextjsFeatures.map((feature, index) => (
                <div
                  key={index}
                  className={`text-center p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedFeature === feature.name 
                      ? 'bg-red-500 text-white shadow-lg mario-glow' 
                      : 'mario-card hover:bg-blue-50 text-gray-700'
                  }`}
                  onClick={() => setSelectedFeature(selectedFeature === feature.name ? '' : feature.name)}
                >
                  <div className={`w-16 h-16 mx-auto mb-2 bg-gradient-to-br ${feature.color} rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-all duration-500`}>
                    <span className="text-2xl filter drop-shadow-sm">{feature.icon}</span>
                  </div>
                  <h3 className="font-bold text-sm mb-1">{feature.name}</h3>
                  <p className="text-xs opacity-80">{feature.desc}</p>
                </div>
              ))}
            </div>
            
            {selectedFeature && (
              <div className="mario-card p-6 border-l-4 border-red-500">
                <h4 className="font-bold text-red-700 mb-3">{selectedFeature} 详解</h4>
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm mb-4">
                  <code className="text-green-400">
                    {nextjsFeatures.find(f => f.name === selectedFeature)?.code}
                  </code>
                </div>
                <p className="text-gray-700 text-sm">
                  {nextjsFeatures.find(f => f.name === selectedFeature)?.detail}
                </p>
              </div>
            )}
          </section>

          {/* 技术栈展示 */}
          <section className="mb-8 mario-section p-6">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🛠️ 全栈技术栈</h2>
            <div className="flex flex-wrap justify-center gap-4">
              {techStack.map((tech, index) => (
                <div key={index} className="mario-card p-4 text-center min-w-[120px]">
                  <div className="text-2xl mb-2">{tech.icon}</div>
                  <h3 className="font-bold text-gray-800 mb-1">{tech.name}</h3>
                  <p className="text-xs text-gray-600">{tech.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* 代码示例展示 */}
          <section className="mb-8 mario-section p-6 bg-gray-900/90">
            <h2 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 Next.js 代码实战</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold text-green-400">🏗️ SSR/SSG 示例</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 服务端渲染 */}</div>
                  <div className="text-green-400">export async function getServerSideProps() {`{`}</div>
                  <div className="ml-4 text-yellow-400">const res = await fetch(&apos;/api/mario&apos;);</div>
                  <div className="ml-4 text-yellow-400">const data = await res.json();</div>
                  <div className="ml-4 text-white">return {`{`}</div>
                  <div className="ml-8 text-purple-400">props: {`{ data }`}</div>
                  <div className="ml-4 text-white">{`}`};</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-bold text-blue-400">🛣️ API Routes 示例</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* API路由 */}</div>
                  <div className="text-green-400">export default function handler(req, res) {`{`}</div>
                  <div className="ml-4 text-yellow-400">const {`{ id }`} = req.query;</div>
                  <div className="ml-4 text-white">res.status(200).json({`{`}</div>
                  <div className="ml-8 text-purple-400">mario: {`{ id, level: 1 }`}</div>
                  <div className="ml-4 text-white">{`}`});</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
              </div>
            </div>
          </section>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/07-async-01" className="font-medium hover:text-green-600 transition-colors">
                React Hooks关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">12</div>
              <p className="text-sm text-gray-600">最终关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">恭喜！</span>
              <p className="font-medium text-green-600">你已完成所有关卡</p>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-yellow-600 border-yellow-800 hover:bg-yellow-700">
              👑 完成关卡，成为全栈大师！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 