'use client';
import { useEffect } from 'react';
import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function DOMManipulationLevel() {
  useEffect(() => {
    // DOM操作相关的JavaScript演示
    console.log("=== 马里奥的DOM冒险开始！ ===");
    
    // 查找元素
    console.log("📍 查找DOM元素：");
    console.log("document.getElementById('mario') - 通过ID查找马里奥");
    console.log("document.querySelector('.coin') - 查找第一个金币");
    console.log("document.querySelectorAll('.enemy') - 查找所有敌人");
    
    // 修改元素属性
    console.log("\n🎨 修改元素样式：");
    console.log("mario.style.left = '100px' - 移动马里奥位置");
    console.log("mario.classList.add('jump') - 添加跳跃动画类");
    console.log("coin.style.display = 'none' - 隐藏收集到的金币");
    
    // 创建新元素
    console.log("\n✨ 创建新游戏元素：");
    console.log("const newCoin = document.createElement('div')");
    console.log("newCoin.className = 'coin animated'");
    console.log("gameArea.appendChild(newCoin) - 添加到游戏区域");
    
    // 事件处理
    console.log("\n🎮 游戏事件处理：");
    console.log("button.addEventListener('click', jumpMario)");
    console.log("document.addEventListener('keydown', handleKeyPress)");
    console.log("coin.addEventListener('click', collectCoin)");
    
    // DOM遍历
    console.log("\n🗂️ DOM结构遍历：");
    console.log("mario.parentNode - 马里奥的父容器");
    console.log("mario.nextSibling - 下一个兄弟元素");
    console.log("gameArea.children - 游戏区域的所有子元素");
    
    // 动态内容更新
    console.log("\n📊 动态更新游戏数据：");
    console.log("scoreElement.textContent = '得分：1500'");
    console.log("livesElement.innerHTML = '<span>❤️</span> × 3'");
    console.log("levelElement.setAttribute('data-level', '2')");
    
    console.log("\n🚀 马里奥的DOM操作技能已激活！");
  }, []);

  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">8</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-6 tracking-widest drop-shadow">🏗️ DOM操作关卡</h1>
            <p className="text-lg text-gray-800 mb-6">掌握DOM操作，让马里奥在网页中自由穿梭！</p>
          </div>
          
          <section className="mb-8 mario-section p-6">
            <h2 className="text-2xl font-black mario-text-gradient mb-4">🎮 DOM操作体验说明</h2>
            <ul className="list-disc list-inside text-gray-700 space-y-2">
              <li>本关卡通过交互式体验展示DOM操作的核心技能。</li>
              <li>页面加载后会在控制台演示DOM操作过程。</li>
              <li>请按 F12 打开浏览器控制台，观察马里奥的DOM冒险！</li>
            </ul>
          </section>

          {/* DOM操作技能展示 */}
          <section className="mb-8 mario-section p-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 text-center">🔧 DOM操作七大技能</h2>
            <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
              {[
                { skill: '查找', icon: '🔍', desc: '定位元素', color: 'from-red-400 to-orange-400', method: 'getElementById' },
                { skill: '创建', icon: '✨', desc: '生成元素', color: 'from-green-400 to-emerald-400', method: 'createElement' },
                { skill: '修改', icon: '🎨', desc: '改变属性', color: 'from-blue-400 to-cyan-400', method: 'style.property' },
                { skill: '插入', icon: '📥', desc: '添加元素', color: 'from-purple-400 to-indigo-400', method: 'appendChild' },
                { skill: '删除', icon: '🗑️', desc: '移除元素', color: 'from-red-500 to-pink-400', method: 'removeChild' },
                { skill: '事件', icon: '⚡', desc: '响应交互', color: 'from-yellow-400 to-orange-400', method: 'addEventListener' },
                { skill: '遍历', icon: '🗂️', desc: '浏览结构', color: 'from-indigo-400 to-purple-400', method: 'children' }
              ].map((item, index) => (
                <div key={index} className="text-center group">
                  <div className={`w-16 h-16 mx-auto mb-2 bg-gradient-to-br ${item.color} rounded-full flex items-center justify-center shadow-lg border-2 border-white hover:scale-110 transition-all duration-300 cursor-pointer group-hover:animate-bounce`}
                       onClick={() => alert(`${item.skill}技能：${item.desc}\n\n核心方法：${item.method}\n\n这是DOM操作的基础技能，让马里奥能够动态控制网页元素！`)}>
                    <span className="text-2xl filter drop-shadow-sm">{item.icon}</span>
                  </div>
                  <h3 className="font-bold text-gray-700 mb-1 text-sm">{item.skill}</h3>
                  <p className="text-xs text-gray-600">{item.desc}</p>
                  {index < 6 && (
                    <div className="hidden md:block absolute mt-8 ml-12 w-8 h-0.5 bg-gradient-to-r from-blue-300 to-transparent"></div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* DOM方法互动体验区 */}
          <section className="mb-8 mario-section p-6">
            <h2 className="text-xl font-black mario-text-gradient mb-4 text-center">🛠️ DOM方法实战体验</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="mario-card p-4 hover:shadow-lg transition-shadow cursor-pointer"
                   onClick={() => alert('查找元素方法：\n\n• getElementById() - 通过ID查找\n• querySelector() - CSS选择器查找\n• querySelectorAll() - 查找所有匹配元素\n\n就像在马里奥世界中定位特定的道具和敌人！')}>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xl">🔍</span>
                  </div>
                  <h3 className="font-bold text-blue-700">元素查找</h3>
                  <p className="text-xs text-blue-600 mt-1">精确定位</p>
                  <code className="text-xs bg-blue-100 px-2 py-1 rounded mt-2 block">querySelector()</code>
                </div>
              </div>
              
              <div className="mario-card p-4 hover:shadow-lg transition-shadow cursor-pointer"
                   onClick={() => alert('样式操作方法：\n\n• element.style.property - 直接修改样式\n• element.classList.add() - 添加CSS类\n• element.setAttribute() - 设置属性\n\n让马里奥动起来，改变颜色和位置！')}>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xl">🎨</span>
                  </div>
                  <h3 className="font-bold text-green-700">样式修改</h3>
                  <p className="text-xs text-green-600 mt-1">动态美化</p>
                  <code className="text-xs bg-green-100 px-2 py-1 rounded mt-2 block">style.left</code>
                </div>
              </div>
              
              <div className="mario-card p-4 hover:shadow-lg transition-shadow cursor-pointer"
                   onClick={() => alert('事件处理方法：\n\n• addEventListener() - 监听事件\n• onclick - 点击事件\n• onkeydown - 键盘事件\n\n让马里奥响应玩家的每一个操作！')}>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-red-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xl">⚡</span>
                  </div>
                  <h3 className="font-bold text-red-700">事件处理</h3>
                  <p className="text-xs text-red-600 mt-1">交互响应</p>
                  <code className="text-xs bg-red-100 px-2 py-1 rounded mt-2 block">addEventListener</code>
                </div>
              </div>
            </div>
          </section>

          {/* 代码示例展示 */}
          <section className="mb-8 mario-section p-6 bg-gray-900/90">
            <h2 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 马里奥DOM操作代码实战</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold text-green-400">🔍 查找和修改元素</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 查找马里奥元素 */}</div>
                  <div className="text-green-400">const mario = document.getElementById(&apos;mario&apos;);</div>
                  <div className="text-green-400">const coins = document.querySelectorAll(&apos;.coin&apos;);</div>
                  <div className="text-yellow-400 mt-2">{/* 修改马里奥位置 */}</div>
                  <div className="text-purple-400">mario.style.left = &apos;200px&apos;;</div>
                  <div className="text-purple-400">mario.classList.add(&apos;jumping&apos;);</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-bold text-blue-400">⚡ 事件处理</h3>
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 马里奥跳跃事件 */}</div>
                  <div className="text-green-400">mario.addEventListener(&apos;click&apos;, function() {`{`}</div>
                  <div className="ml-4 text-yellow-400">mario.style.transform = &apos;translateY(-50px)&apos;;</div>
                  <div className="ml-4 text-yellow-400">setTimeout(() =&gt; {`{`}</div>
                  <div className="ml-8 text-white">mario.style.transform = &apos;translateY(0)&apos;;</div>
                  <div className="ml-4 text-yellow-400">{`}`}, 500);</div>
                  <div className="text-green-400">{`}`});</div>
                </div>
              </div>
            </div>
          </section>

          {/* DOM树结构展示 */}
          <section className="mario-section p-6">
            <h2 className="text-2xl font-black mario-text-gradient text-center mb-6">🌳 马里奥世界DOM树结构</h2>
            
            <div className="mario-card p-6">
              <div className="bg-gray-900 rounded-lg p-6 font-mono text-sm overflow-x-auto">
                <div className="text-yellow-300 mb-4">{/* 马里奥游戏DOM结构 */}</div>
                <div className="space-y-1">
                  <div className="text-blue-400">&lt;div id=&quot;game-container&quot;&gt;</div>
                  <div className="ml-4 text-green-400">&lt;div id=&quot;mario&quot; class=&quot;character&quot;&gt;🍄&lt;/div&gt;</div>
                  <div className="ml-4 text-yellow-400">&lt;div class=&quot;coins&quot;&gt;</div>
                  <div className="ml-8 text-orange-400">&lt;div class=&quot;coin&quot;&gt;🪙&lt;/div&gt;</div>
                  <div className="ml-8 text-orange-400">&lt;div class=&quot;coin&quot;&gt;🪙&lt;/div&gt;</div>
                  <div className="ml-4 text-yellow-400">&lt;/div&gt;</div>
                  <div className="ml-4 text-red-400">&lt;div class=&quot;enemies&quot;&gt;</div>
                  <div className="ml-8 text-pink-400">&lt;div class=&quot;goomba&quot;&gt;👾&lt;/div&gt;</div>
                  <div className="ml-4 text-red-400">&lt;/div&gt;</div>
                  <div className="ml-4 text-purple-400">&lt;div id=&quot;score&quot;&gt;得分：0&lt;/div&gt;</div>
                  <div className="text-blue-400">&lt;/div&gt;</div>
                </div>
              </div>
            </div>
          </section>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/04-css-02" className="font-medium hover:text-green-600 transition-colors">
                JavaScript基础关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">8</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/06-news01" className="font-medium hover:text-green-600 transition-colors">
                DOM进阶关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-blue-600 border-blue-800 hover:bg-blue-700">
              🏗️ 完成关卡，掌握DOM操作！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 