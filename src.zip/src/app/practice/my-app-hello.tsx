export default function MyAppHello() {
  return (
    <div style={{ padding: '10px', color: '#e11d48' }}>
      <p>欢迎来到超级马里奥编程学习工坊！</p>
      <p style={{ fontSize: '14px', color: '#be123c', marginTop: '5px' }}>
        让编程学习像玩马里奥游戏一样有趣！
      </p>
    </div>
  );
} 