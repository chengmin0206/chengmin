import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function CSSAnimationLevel() {
  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl power-up-glow">5</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-4 tracking-widest drop-shadow">✨ CSS动画关卡</h1>
            <h3 className="text-xl font-bold text-gray-700 mb-6 leading-relaxed">让网页像马里奥跳跃一样充满动感！</h3>
          </div>

          <div className="mario-section p-6 mb-8">
            <h3 className="text-xl font-black mario-text-gradient mb-4 text-center">🎬 CSS动画技术进阶</h3>
            <table className="mx-auto w-4/5 border-separate border-spacing-y-2 mb-8">
              <tbody>
                <tr><td className="text-red-600 py-3 border-b-2 border-red-300 text-center font-medium">5.1 Transition过渡 - 平滑状态变化</td></tr>
                <tr><td className="text-green-600 py-3 border-b-2 border-green-300 text-center font-medium">5.2 Transform变换 - 2D/3D图形变换</td></tr>
                <tr><td className="text-blue-600 py-3 border-b-2 border-blue-300 text-center font-medium">5.3 Animation动画 - 复杂关键帧动画</td></tr>
                <tr><td className="text-yellow-600 py-3 border-b-2 border-yellow-300 text-center font-medium">5.4 交互动画 - 用户交互响应动画</td></tr>
              </tbody>
            </table>
          </div>

          <div className="mb-8">
            <h4 className="text-center text-lg font-semibold mb-4 mario-text-gradient">🔍 动画资源搜索</h4>
            <form className="flex justify-center gap-3 mario-card p-4">
              <input 
                type="text" 
                defaultValue="CSS动画效果教程" 
                placeholder="搜索CSS动画教程" 
                className="px-4 py-2 border-2 border-blue-500 rounded-md w-72 focus:outline-none focus:border-green-500 transition-colors" 
              />
              <button 
                type="submit" 
                className="mario-button px-6 py-2 rounded-md font-bold transition-all hover:scale-105"
              >
                🚀 搜索
              </button>
            </form>
          </div>

          {/* 动画演示区 */}
          <div className="space-y-8">
            <div className="mario-section p-6 bg-gradient-to-r from-red-100 to-blue-100">
              <p className="text-gray-800 text-lg text-center mb-6 font-medium">CSS动画让网页变得生动有趣，就像马里奥世界一样充满活力和魅力！</p>
              
              {/* 动画示例 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="mario-card p-4 text-center">
                  <h4 className="font-bold text-red-700 mb-3">🎮 跳跃动画</h4>
                  <div className="mario-button px-4 py-2 text-sm hover:scale-110 transition-transform cursor-pointer">
                    马里奥跳跃
                  </div>
                </div>
                
                <div className="mario-card p-4 text-center">
                  <h4 className="font-bold text-green-700 mb-3">🪙 旋转金币</h4>
                  <div className="mario-coin w-12 h-12 mx-auto cursor-pointer"></div>
                </div>
                
                <div className="mario-card p-4 text-center">
                  <h4 className="font-bold text-blue-700 mb-3">🧱 弹跳砖块</h4>
                  <div className="w-12 h-8 bg-orange-600 border-2 border-orange-800 rounded-sm mx-auto mario-brick cursor-pointer"></div>
                </div>
              </div>
            </div>

            {/* 代码演示 */}
            <div className="mario-section p-6 bg-gray-900/90">
              <h3 className="text-xl font-bold text-yellow-300 mb-4 text-center">💻 马里奥动画代码实战</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 马里奥跳跃动画 */}</div>
                  <div className="text-green-400">@keyframes mario-jump {`{`}</div>
                  <div className="ml-4 text-yellow-400">0%, 100% {`{`}</div>
                  <div className="ml-8 text-white">transform: translateY(0px);</div>
                  <div className="ml-4 text-yellow-400">{`}`}</div>
                  <div className="ml-4 text-yellow-400">50% {`{`}</div>
                  <div className="ml-8 text-white">transform: translateY(-10px);</div>
                  <div className="ml-4 text-yellow-400">{`}`}</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
                
                <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm">
                  <div className="text-blue-400">{/* 金币旋转动画 */}</div>
                  <div className="text-green-400">@keyframes coin-spin {`{`}</div>
                  <div className="ml-4 text-yellow-400">0% {`{`}</div>
                  <div className="ml-8 text-white">transform: rotateY(0deg);</div>
                  <div className="ml-4 text-yellow-400">{`}`}</div>
                  <div className="ml-4 text-yellow-400">100% {`{`}</div>
                  <div className="ml-8 text-white">transform: rotateY(360deg);</div>
                  <div className="ml-4 text-yellow-400">{`}`}</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
              </div>
            </div>

            {/* 动画技术要点 */}
            <div className="mario-section p-6">
              <h2 className="text-2xl font-black mario-text-gradient text-center mb-6">🎨 CSS动画核心技术</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="mario-card p-4">
                  <h4 className="font-bold text-red-600 mb-3 flex items-center gap-2">
                    <span className="mario-coin w-6 h-6 rounded-full"></span>
                    过渡动画
                  </h4>
                  <p className="text-gray-700 text-sm mb-2">简单状态变化的平滑过渡效果</p>
                  <code className="bg-red-100 text-red-700 px-2 py-1 rounded text-xs">transition: all 0.3s ease;</code>
                </div>
                
                <div className="mario-card p-4">
                  <h4 className="font-bold text-green-600 mb-3 flex items-center gap-2">
                    <span className="mario-coin w-6 h-6 rounded-full"></span>
                    变换动画
                  </h4>
                  <p className="text-gray-700 text-sm mb-2">元素的位移、旋转、缩放等变换</p>
                  <code className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs">transform: rotate(45deg);</code>
                </div>
                
                <div className="mario-card p-4">
                  <h4 className="font-bold text-blue-600 mb-3 flex items-center gap-2">
                    <span className="mario-coin w-6 h-6 rounded-full"></span>
                    关键帧动画
                  </h4>
                  <p className="text-gray-700 text-sm mb-2">复杂的自定义动画序列</p>
                  <code className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">animation: jump 1s infinite;</code>
                </div>
              </div>
            </div>
          </div>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/03-css-02" className="font-medium hover:text-green-600 transition-colors">
                CSS布局关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">5</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/04-css-02" className="font-medium hover:text-green-600 transition-colors">
                JavaScript基础关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-purple-600 border-purple-800 hover:bg-purple-700 power-up-glow">
              ✨ 完成关卡，掌握CSS动画！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 