import Link from 'next/link';
import MyAppDemo from "../my-app-demo";
import MyAppHello from "../my-app-hello";
import MarioBackground from "../../components/mario-background";

export default function HTMLBasicLevel() {
  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button inline-block px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <section className="max-w-3xl mx-auto mb-10 mario-section p-8 flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-shrink-0">
              {/* HTML关卡展示 */}
              <div className="w-56 h-36 bg-gradient-to-br from-red-100 to-blue-200 rounded-lg shadow-lg border-3 border-blue-300 p-4 relative overflow-hidden">
                <div className="absolute inset-0 opacity-20 bg-repeat bg-cover" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23F44336' fill-opacity='0.1'%3E%3Cpath d='M20 20c0 2.76-2.24 5-5 5s-5-2.24-5-5 2.24-5 5-5 5 2.24 5 5zm5-10c0 2.76-2.24 5-5 5s-5-2.24-5-5 2.24-5 5-5 5 2.24 5 5z'/%3E%3C/g%3E%3C/svg%3E")` }}></div>
                <div className="relative z-10">
                  <div className="level-badge mb-2 mx-auto">1</div>
                  <h3 className="text-blue-700 font-bold text-lg mb-2">HTML基础</h3>
                  <div className="space-y-1 text-sm text-blue-600">
                    <div className="flex items-center gap-2">
                      <div className="mario-coin w-3 h-3 rounded-full"></div>
                      <span>标签结构</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="mario-coin w-3 h-3 rounded-full"></div>
                      <span>语义化</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="mario-coin w-3 h-3 rounded-full"></div>
                      <span>文档结构</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-black mario-text-gradient mb-2">🏁 HTML基础关卡</h2>
              <p className="text-gray-800 mb-4">欢迎来到编程世界的第一关！就像马里奥从第一关开始冒险一样，我们从HTML基础开始学习网页开发。掌握HTML标签和文档结构，为编程之旅打下坚实基础。</p>
              <div className="flex gap-2 flex-wrap">
                <span className="bg-red-100 text-red-700 border-2 border-red-300 px-3 py-1 rounded-full text-xs font-bold">HTML</span>
                <span className="bg-green-100 text-green-700 border-2 border-green-300 px-3 py-1 rounded-full text-xs font-bold">基础关卡</span>
                <span className="bg-blue-100 text-blue-700 border-2 border-blue-300 px-3 py-1 rounded-full text-xs font-bold">Level 1</span>
              </div>
            </div>
          </section>
          
          {/* HTML学习流程展示 */}
          <div className="mb-8 mario-section p-6">
            <h2 className="text-2xl font-black mario-text-gradient mb-4 text-center">🎯 HTML学习路径</h2>
            <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
              {[
                { step: 'DOCTYPE', icon: '📄', desc: '文档声明' },
                { step: 'HTML标签', icon: '🏗️', desc: '根元素' },
                { step: 'Head区域', icon: '🧠', desc: '元数据' },
                { step: 'Body内容', icon: '💪', desc: '页面主体' },
                { step: '标题标签', icon: '📰', desc: 'h1-h6' },
                { step: '段落文本', icon: '📝', desc: 'p标签' },
                { step: '链接图片', icon: '🔗', desc: 'a和img' }
              ].map((item, index) => (
                <div key={index} className="text-center relative">
                  <div className="w-16 h-16 mx-auto mb-2 bg-white rounded-full flex items-center justify-center shadow-md border-3 border-blue-300 hover:scale-110 transition-transform cursor-pointer mario-card">
                    <span className="text-2xl">{item.icon}</span>
                  </div>
                  <h3 className="font-bold text-blue-700 mb-1">{item.step}</h3>
                  <p className="text-xs text-gray-600">{item.desc}</p>
                  {index < 6 && <div className="hidden md:block absolute top-8 right-0 w-full h-0.5 bg-gradient-to-r from-red-400 to-green-400 transform translate-x-8"></div>}
                </div>
              ))}
            </div>
          </div>

          <h1 className="text-4xl font-black mario-text-gradient mb-6 text-center">🎮 HTML编程实战区</h1>
          <div className="space-y-6">
            <div className="mario-section bg-gray-900/90 text-green-400 font-mono rounded-lg p-6 shadow-xl">
              <h3 className="text-lg font-bold mb-3 text-yellow-300 flex items-center gap-2">
                💻 HTML基础代码演示
              </h3>
              <MyAppDemo />
            </div>
            <div className="mario-section bg-gray-900/90 text-green-400 font-mono rounded-lg p-6 shadow-xl">
              <h3 className="text-lg font-bold mb-3 text-yellow-300 flex items-center gap-2">
                🚀 马里奥主题实例
              </h3>
              <MyAppHello />
            </div>
          </div>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-500">
              <span className="text-sm">上一关：</span>
              <p className="font-medium">无（这是第一关）</p>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">1</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/index" className="font-medium hover:text-green-600 transition-colors">
                HTML进阶关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-green-600 border-green-800 hover:bg-green-700">
              🎉 完成关卡，收集金币！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 