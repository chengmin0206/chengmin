import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function HTMLAdvancedLevel() {
  return (
    <MarioBackground>
      <div className="py-6 px-2 relative overflow-hidden">
        <div className="max-w-5xl mx-auto relative z-10">
          <header className="text-center py-10 mario-section mb-8 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              <div className="flex justify-center items-end h-full pb-4 gap-2">
                <div className="w-8 h-12 bg-yellow-400 rounded-t transform -rotate-12"></div>
                <div className="w-6 h-16 bg-red-500 rounded-t transform rotate-6"></div>
                <div className="w-10 h-20 bg-green-500 rounded-t"></div>
                <div className="w-8 h-14 bg-blue-500 rounded-t transform -rotate-6"></div>
                <div className="w-12 h-18 bg-yellow-400 rounded-t transform rotate-12"></div>
              </div>
            </div>
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">2</div>
            <h1 className="text-4xl md:text-5xl font-black mario-text-gradient tracking-widest drop-shadow-lg relative z-10">🏗️ HTML进阶关卡</h1>
            <p className="text-gray-800 mt-3 text-lg font-semibold relative z-10">深入HTML世界·掌握高级技能</p>
          </header>

          <div className="mario-card max-w-2xl mx-auto mb-8 p-8 hover:-translate-y-1 transition-transform">
            <h3 className="text-xl font-bold mario-text-gradient mb-4 flex items-center gap-2">✨ HTML学习进程</h3>
            <table className="w-full border-separate border-spacing-y-2">
              <tbody>
                <tr><td className="pl-4 border-l-4 border-red-500 py-2 text-gray-700">Level 1 - 基础标签结构</td></tr>
                <tr><td className="pl-4 border-l-4 border-green-500 py-2 text-gray-700">Level 2 - 语义化标签 ⭐当前关卡</td></tr>
                <tr><td className="pl-4 border-l-4 border-blue-500 py-2 text-gray-500">Level 3 - 表单与交互</td></tr>
                <tr><td className="pl-4 border-l-4 border-yellow-500 py-2 text-gray-500">Level 4 - 多媒体元素</td></tr>
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="mario-card p-6">
              <h3 className="text-lg font-black mario-text-gradient border-b-2 border-yellow-500 pb-2 mb-3 flex items-center gap-2">🏯 语义化标签</h3>
              <ol className="list-decimal list-inside text-gray-700 space-y-2 text-sm">
                <li><code className="bg-red-100 px-2 py-1 rounded text-red-700">header</code> - 页面头部区域</li>
                <li><code className="bg-green-100 px-2 py-1 rounded text-green-700">nav</code> - 导航菜单区域</li>
                <li><code className="bg-blue-100 px-2 py-1 rounded text-blue-700">main</code> - 主要内容区域</li>
                <li><code className="bg-yellow-100 px-2 py-1 rounded text-yellow-700">footer</code> - 页面底部区域</li>
              </ol>
            </div>
            
            <div className="mario-card p-6">
              <h3 className="text-lg font-black mario-text-gradient border-b-2 border-yellow-500 pb-2 mb-3 flex items-center gap-2">🏗️ 结构标签</h3>
              <ul className="columns-1 gap-2 list-none p-0 space-y-2 text-sm">
                <li className="relative pl-6 before:content-['🎮'] before:absolute before:left-0 text-red-700"><code>section</code> - 章节分区</li>
                <li className="relative pl-6 before:content-['🎮'] before:absolute before:left-0 text-green-700"><code>article</code> - 独立文章</li>
                <li className="relative pl-6 before:content-['🎮'] before:absolute before:left-0 text-blue-700"><code>aside</code> - 侧边内容</li>
                <li className="relative pl-6 before:content-['🎮'] before:absolute before:left-0 text-yellow-700"><code>figure</code> - 图片说明</li>
              </ul>
            </div>
          </div>

          <div className="flex justify-center mb-8">
            <form className="flex gap-3 w-full max-w-xl mario-card p-4">
              <input 
                type="text" 
                placeholder="搜索HTML标签..." 
                className="flex-1 px-5 py-3 border-2 border-blue-500 rounded-full text-base focus:outline-none focus:border-green-500 transition" 
              />
              <button 
                type="submit" 
                className="mario-button px-8 py-3 rounded-full font-bold shadow-md hover:scale-105 transition"
              >
                🚀 搜索
              </button>
            </form>
          </div>

          <div className="mario-section p-8 mb-8">
            <h2 className="text-2xl font-black mario-text-gradient mb-6 flex items-center gap-2">🏛️ HTML进阶实战</h2>
            
            <div className="bg-gradient-to-b from-green-100 to-blue-100 rounded-xl p-8 mb-6 relative overflow-hidden">
              <div className="absolute inset-0 opacity-20">
                <svg viewBox="0 0 800 200" className="w-full h-full">
                  <polygon points="100,160 150,120 200,160" fill="#4CAF50" />
                  <rect x="120" y="160" width="60" height="30" fill="#4CAF50" />
                  <polygon points="300,150 380,100 460,150" fill="#2196F3" />
                  <rect x="340" y="150" width="80" height="40" fill="#2196F3" />
                  <polygon points="500,140 600,80 700,140" fill="#F44336" />
                  <rect x="550" y="140" width="100" height="50" fill="#F44336" />
                </svg>
              </div>
              <div className="relative z-10 text-center">
                <h3 className="text-xl font-bold mario-text-gradient mb-4">马里奥HTML城堡</h3>
                <p className="text-gray-700 mb-4">用语义化标签构建完整的网页结构，就像建造马里奥的城堡！</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="mario-card p-4">
                    <h4 className="font-bold text-red-700 flex items-center gap-1">🏮 Header区域</h4>
                    <p className="text-gray-600 text-xs">导航栏、Logo、标题</p>
                  </div>
                  <div className="mario-card p-4">
                    <h4 className="font-bold text-green-700 flex items-center gap-1">🎋 Main内容</h4>
                    <p className="text-gray-600 text-xs">文章、列表、表单</p>
                  </div>
                  <div className="mario-card p-4">
                    <h4 className="font-bold text-blue-700 flex items-center gap-1">🏛️ Footer底部</h4>
                    <p className="text-gray-600 text-xs">版权、链接、联系方式</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mario-section text-center py-6 mb-6 bg-gradient-to-r from-green-600 to-blue-600">
              <h4 className="text-white text-lg font-bold mb-2">🎯 挑战任务</h4>
              <p className="text-green-100 text-sm">使用语义化标签重构一个完整的网页</p>
            </div>
            
            <div className="mario-card p-6 border-2 border-blue-300">
              <h3 className="text-xl font-black mario-text-gradient mb-4 text-center">📚 代码演示区</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-bold text-red-600 flex items-center gap-2">🔨 基础结构</h4>
                  <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm">
                    <div className="text-blue-400">&lt;!DOCTYPE html&gt;</div>
                    <div className="text-yellow-400">&lt;html lang=&quot;zh&quot;&gt;</div>
                    <div className="ml-2 text-green-400">&lt;head&gt;</div>
                    <div className="ml-4 text-gray-400">&lt;title&gt;马里奥页面&lt;/title&gt;</div>
                    <div className="ml-2 text-green-400">&lt;/head&gt;</div>
                    <div className="ml-2 text-red-400">&lt;body&gt;...&lt;/body&gt;</div>
                    <div className="text-yellow-400">&lt;/html&gt;</div>
                  </div>
                </div>
                <div className="space-y-3">
                  <h4 className="font-bold text-green-600 flex items-center gap-2">🎨 语义化标签</h4>
                  <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm">
                    <div className="text-blue-400">&lt;header&gt;</div>
                    <div className="ml-2 text-yellow-400">&lt;nav&gt;导航&lt;/nav&gt;</div>
                    <div className="text-blue-400">&lt;/header&gt;</div>
                    <div className="text-red-400">&lt;main&gt;</div>
                    <div className="ml-2 text-green-400">&lt;article&gt;文章&lt;/article&gt;</div>
                    <div className="text-red-400">&lt;/main&gt;</div>
                    <div className="text-purple-400">&lt;footer&gt;底部&lt;/footer&gt;</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/my-app" className="font-medium hover:text-green-600 transition-colors">
                HTML基础关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">2</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/03-css-01" className="font-medium hover:text-green-600 transition-colors">
                CSS样式关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-blue-600 border-blue-800 hover:bg-blue-700">
              🎉 完成关卡，获得语义化技能！
            </button>
          </div>

          <div className="text-center mt-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 