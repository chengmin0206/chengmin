import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function CSSStyleLevel() {
  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-2xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">3</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-4 tracking-widest drop-shadow">🎨 CSS样式关卡</h1>
            <p className="text-gray-800 text-lg">用CSS让网页变得像马里奥世界一样炫酷！</p>
          </div>

          <div className="mario-card p-8 border-2 border-blue-300">
            <h2 className="text-2xl font-black mario-text-gradient mb-4 flex items-center gap-2">🎨 CSS样式的三种使用方式</h2>
            <ul className="list-disc list-inside text-lg text-gray-700 space-y-3 pl-4">
              <li className="flex items-center gap-3">
                <span className="mario-coin w-6 h-6 rounded-full flex-shrink-0"></span>
                <span><code className="bg-red-100 px-2 py-1 rounded text-red-700">内联样式</code> - 直接在HTML标签中使用style属性</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="mario-coin w-6 h-6 rounded-full flex-shrink-0"></span>
                <span><code className="bg-green-100 px-2 py-1 rounded text-green-700">内部样式</code> - 在HTML文档头部使用&lt;style&gt;标签</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="mario-coin w-6 h-6 rounded-full flex-shrink-0"></span>
                <span><code className="bg-blue-100 px-2 py-1 rounded text-blue-700">外部样式</code> - 使用单独的.css文件，通过&lt;link&gt;引入</span>
              </li>
            </ul>
            
            <div className="mt-6 mario-section p-4 bg-gradient-to-r from-green-100 to-blue-100">
              <p className="text-gray-800 text-sm text-center flex items-center justify-center gap-2">
                <span className="text-2xl">🎮</span>
                CSS是网页的化妆师，让马里奥的网页世界变得绚丽多彩！
              </p>
            </div>
          </div>

          {/* 代码演示区 */}
          <div className="mario-section mt-8 p-6 bg-gray-900/90">
            <h3 className="text-xl font-bold text-yellow-300 mb-4 flex items-center gap-2">
              💻 马里奥风格CSS代码演示
            </h3>
            
            <div className="bg-gray-800 rounded-lg p-4 font-mono text-sm mb-4">
              <div className="text-blue-400">{/* 马里奥按钮样式 */}</div>
              <div className="text-green-400">.mario-button {`{`}</div>
              <div className="ml-4 text-yellow-400">background: linear-gradient(45deg, #F44336, #E53935);</div>
              <div className="ml-4 text-yellow-400">border: 3px solid #C62828;</div>
              <div className="ml-4 text-yellow-400">border-radius: 25px;</div>
              <div className="ml-4 text-yellow-400">color: white;</div>
              <div className="ml-4 text-yellow-400">font-weight: bold;</div>
              <div className="ml-4 text-yellow-400">transition: all 0.3s ease;</div>
              <div className="text-green-400">{`}`}</div>
              <div className="mt-2 text-blue-400">{/* 鼠标悬停效果 */}</div>
              <div className="text-green-400">.mario-button:hover {`{`}</div>
              <div className="ml-4 text-yellow-400">transform: translateY(-2px);</div>
              <div className="ml-4 text-yellow-400">box-shadow: 0 5px 15px rgba(244, 67, 54, 0.4);</div>
              <div className="text-green-400">{`}`}</div>
            </div>
            
            <div className="text-center">
              <button className="mario-button px-8 py-3 text-lg font-bold">
                🚀 马里奥样式按钮演示
              </button>
            </div>
          </div>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/index" className="font-medium hover:text-green-600 transition-colors">
                HTML进阶关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">3</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/03-css-02" className="font-medium hover:text-green-600 transition-colors">
                CSS布局关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-red-600 border-red-800 hover:bg-red-700">
              🎨 完成关卡，掌握CSS样式！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 