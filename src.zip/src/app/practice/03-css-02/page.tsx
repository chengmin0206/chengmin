import Link from 'next/link';
import MarioBackground from "../../components/mario-background";

export default function CSSLayoutLevel() {
  return (
    <MarioBackground>
      <div className="py-8 px-2 relative overflow-hidden">
        <div className="max-w-3xl mx-auto relative z-10">
          <div className="mb-8">
            <Link href="/" className="mario-button px-6 py-3 text-sm font-bold">← 返回超级学习工坊</Link>
          </div>
          
          <div className="text-center mb-8">
            <div className="level-badge mx-auto mb-4 w-16 h-16 text-xl">4</div>
            <h1 className="text-4xl font-black mario-text-gradient mb-4 tracking-widest drop-shadow">🏗️ CSS布局关卡</h1>
            <p className="text-gray-800 text-lg">掌握Flexbox和Grid，像马里奥在复杂地形中自由穿梭！</p>
          </div>

          <section className="mb-8 mario-section p-6">
            <h2 className="text-2xl font-black mario-text-gradient mb-4 flex items-center gap-2">📐 布局系统说明</h2>
            <ul className="list-disc list-inside text-gray-700 space-y-2">
              <li>CSS布局是网页构建的基础，就像马里奥游戏关卡的地形设计一样重要。</li>
              <li>观察下方不同布局方式的特点和使用场景，掌握现代CSS布局技术。</li>
            </ul>
          </section>

          <div className="mario-section p-8 mb-8 bg-gradient-to-br from-green-100 to-blue-100">
            <h3 className="text-xl font-black mario-text-gradient mb-6 text-center">🎯 CSS布局技术演示</h3>
            
            <div className="space-y-6">
              {/* Flexbox 演示 */}
              <div className="mario-card p-6">
                <h4 className="text-lg font-bold text-green-600 mb-3 flex items-center gap-2">
                  <span className="mario-coin w-6 h-6 rounded-full"></span>
                  Flexbox 弹性布局
                </h4>
                <p className="text-gray-700 mb-4">像马里奥的弹簧一样灵活，一维布局的最佳选择！</p>
                
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm mb-4">
                  <div className="text-blue-400">{/* Flexbox 容器 */}</div>
                  <div className="text-green-400">.flex-container {`{`}</div>
                  <div className="ml-4 text-yellow-400">display: flex;</div>
                  <div className="ml-4 text-yellow-400">justify-content: space-between;</div>
                  <div className="ml-4 text-yellow-400">align-items: center;</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
                
                <div className="bg-green-100 p-4 rounded-lg flex justify-between items-center gap-4">
                  <div className="mario-button text-sm px-4 py-2">马里奥</div>
                  <div className="mario-button text-sm px-4 py-2 bg-green-600 border-green-800">路易吉</div>
                  <div className="mario-button text-sm px-4 py-2 bg-yellow-600 border-yellow-800">皮卡丘</div>
                </div>
              </div>

              {/* Grid 演示 */}
              <div className="mario-card p-6">
                <h4 className="text-lg font-bold text-blue-600 mb-3 flex items-center gap-2">
                  <span className="mario-coin w-6 h-6 rounded-full"></span>
                  CSS Grid 网格布局
                </h4>
                <p className="text-gray-700 mb-4">像马里奥关卡的砖块网格，二维布局的强大工具！</p>
                
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm mb-4">
                  <div className="text-blue-400">{/* Grid 容器 */}</div>
                  <div className="text-green-400">.grid-container {`{`}</div>
                  <div className="ml-4 text-yellow-400">display: grid;</div>
                  <div className="ml-4 text-yellow-400">grid-template-columns: repeat(3, 1fr);</div>
                  <div className="ml-4 text-yellow-400">gap: 1rem;</div>
                  <div className="text-green-400">{`}`}</div>
                </div>
                
                <div className="bg-blue-100 p-4 rounded-lg grid grid-cols-3 gap-4">
                  <div className="bg-orange-600 border-2 border-orange-800 rounded-sm h-12 flex items-center justify-center text-white font-bold text-sm">砖块1</div>
                  <div className="bg-orange-600 border-2 border-orange-800 rounded-sm h-12 flex items-center justify-center text-white font-bold text-sm">砖块2</div>
                  <div className="bg-orange-600 border-2 border-orange-800 rounded-sm h-12 flex items-center justify-center text-white font-bold text-sm">砖块3</div>
                  <div className="bg-yellow-400 border-2 border-yellow-600 rounded-full h-12 flex items-center justify-center text-yellow-800 font-bold text-sm">金币</div>
                  <div className="bg-green-600 border-2 border-green-800 rounded h-12 flex items-center justify-center text-white font-bold text-sm">管道</div>
                  <div className="bg-red-600 border-2 border-red-800 rounded h-12 flex items-center justify-center text-white font-bold text-sm">蘑菇</div>
                </div>
              </div>

              {/* 定位演示 */}
              <div className="mario-card p-6">
                <h4 className="text-lg font-bold text-purple-600 mb-3 flex items-center gap-2">
                  <span className="mario-coin w-6 h-6 rounded-full"></span>
                  CSS Position 定位
                </h4>
                <p className="text-gray-700 mb-4">像马里奥的精确跳跃，控制元素的准确位置！</p>
                
                <div className="bg-purple-100 p-4 rounded-lg relative h-24">
                  <div className="absolute top-2 left-2 bg-red-600 text-white px-3 py-1 rounded text-sm font-bold">绝对定位</div>
                  <div className="absolute top-2 right-2 bg-green-600 text-white px-3 py-1 rounded text-sm font-bold">右上角</div>
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-3 py-1 rounded text-sm font-bold">底部居中</div>
                </div>
              </div>
            </div>
          </div>

          {/* 关卡导航 */}
          <div className="flex justify-between items-center mt-12 mario-section p-6">
            <div className="text-gray-700">
              <span className="text-sm">上一关：</span>
              <Link href="/practice/03-css-01" className="font-medium hover:text-green-600 transition-colors">
                CSS样式关卡
              </Link>
            </div>
            
            <div className="text-center">
              <div className="level-badge mx-auto mb-2 w-16 h-16 text-xl">4</div>
              <p className="text-sm text-gray-600">当前关卡</p>
            </div>
            
            <div className="text-gray-700 text-right">
              <span className="text-sm">下一关：</span>
              <Link href="/practice/04-css-01" className="font-medium hover:text-green-600 transition-colors">
                CSS动画关卡
              </Link>
            </div>
          </div>

          {/* 完成按钮 */}
          <div className="text-center mt-8">
            <button className="mario-button px-12 py-4 text-lg font-bold bg-blue-600 border-blue-800 hover:bg-blue-700">
              🏗️ 完成关卡，掌握CSS布局！
            </button>
          </div>
        </div>
      </div>
    </MarioBackground>
  );
} 