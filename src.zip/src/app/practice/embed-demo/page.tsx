"use client";
import React, { useState, useEffect, useRef } from "react";
import MarioBackground from "../../components/mario-background";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp?: number;
}

interface KnowledgeBase {
  kbId: string;
  kbName: string;
}

interface ChatHistory {
  id: string;
  title: string;
  messages: Message[];
  kbId: string;
  createdAt: number;
  updatedAt: number;
}

export default function ChatDemo() {
  const [kbList, setKbList] = useState<KnowledgeBase[]>([]);
  const [selectedKbId, setSelectedKbId] = useState<string>("");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [chatHistories, setChatHistories] = useState<ChatHistory[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string>("");
  const [showQuickQuestions, setShowQuickQuestions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 马里奥快速提问
  const quickQuestions = [
    "马里奥的基本操作有哪些？",
    "如何打败库巴？",
    "金币有什么用途？",
    "蘑菇道具的效果是什么？",
    "火焰花的作用是什么？",
    "无敌星的持续时间？",
    "绿色管道有什么用？",
    "如何找到隐藏关卡？",
    "1UP蘑菇在哪里找？",
    "如何救出公主？",
    "城堡关卡的攻略？",
    "水下关卡怎么过？"
  ];

  // 游戏小贴士
  const culturalTips = [
    "💡 游戏技巧：按住跑步键可以跳得更远，这是通过困难关卡的关键！",
    "🌟 隐藏道具：许多砖块中都藏着道具，试着都跳一跳看看吧！",
    "🍄 能力提升：吃到超级蘑菇会变大，获得更强的能力！",
    "🔥 战斗技巧：火焰花可以发射火球，是对付敌人的利器！",
    "⭐ 游戏精神：不断尝试、永不放弃，就像马里奥一样勇往直前！"
  ];

  const [currentTip, setCurrentTip] = useState(0);

  // 生成对话标题
  const generateChatTitle = (messages: Message[]): string => {
    const firstUserMessage = messages.find(msg => msg.role === "user");
    if (firstUserMessage) {
      return firstUserMessage.content.slice(0, 20) + (firstUserMessage.content.length > 20 ? "..." : "");
    }
    return "新对话";
  };

  // 保存对话历史到localStorage
  const saveChatHistory = (chatId: string, messages: Message[], kbId: string) => {
    const histories = JSON.parse(localStorage.getItem('heritage_chat_histories') || '[]') as ChatHistory[];
    const existingIndex = histories.findIndex(h => h.id === chatId);
    
    const chatData: ChatHistory = {
      id: chatId,
      title: generateChatTitle(messages),
      messages: messages,
      kbId: kbId,
      createdAt: existingIndex === -1 ? Date.now() : histories[existingIndex].createdAt,
      updatedAt: Date.now()
    };

    if (existingIndex === -1) {
      histories.unshift(chatData);
    } else {
      histories[existingIndex] = chatData;
    }

    // 只保留最近50条对话历史
    const trimmedHistories = histories.slice(0, 50);
    localStorage.setItem('heritage_chat_histories', JSON.stringify(trimmedHistories));
    setChatHistories(trimmedHistories);
  };

  // 加载对话历史
  const loadChatHistories = () => {
    const histories = JSON.parse(localStorage.getItem('heritage_chat_histories') || '[]') as ChatHistory[];
    setChatHistories(histories);
  };

  // 新建对话
  const createNewChat = () => {
    const newChatId = `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setCurrentChatId(newChatId);
    setMessages([]);
    setError("");
  };

  // 加载指定对话
  const loadChat = (chatId: string) => {
    const chat = chatHistories.find(h => h.id === chatId);
    if (chat) {
      setCurrentChatId(chatId);
      setMessages(chat.messages);
      setSelectedKbId(chat.kbId);
      setError("");
    }
  };

  // 删除对话
  const deleteChat = (chatId: string) => {
    const updatedHistories = chatHistories.filter(h => h.id !== chatId);
    localStorage.setItem('heritage_chat_histories', JSON.stringify(updatedHistories));
    setChatHistories(updatedHistories);
    
    if (currentChatId === chatId) {
      createNewChat();
    }
  };

  // 处理快速提问
  const handleQuickQuestion = (question: string) => {
    setInput(question);
    setShowQuickQuestions(false);
    // 延迟一点自动发送，让用户看到问题被填入
    setTimeout(() => {
      if (selectedKbId) {
        handleSend();
      }
    }, 500);
  };

  // 获取知识库列表
  useEffect(() => {
    async function fetchKnowledgeBases() {
      try {
        const res = await fetch('/api/youdao-kb-list');
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || '获取文化知识库失败');
        }
        const data = await res.json();
        setKbList(data);
        // 自动选择第一个知识库
        if (data.length > 0) {
          setSelectedKbId(data[0].kbId);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : '获取文化知识库失败');
      }
    }
    fetchKnowledgeBases();
    loadChatHistories();
    createNewChat();
  }, []);

  // 自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // 保存当前对话到历史记录
  useEffect(() => {
    if (currentChatId && messages.length > 0 && selectedKbId) {
      saveChatHistory(currentChatId, messages, selectedKbId);
    }
  }, [messages, currentChatId, selectedKbId]);

  // 文化小贴士轮播
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % culturalTips.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  // 发送消息
  async function handleSend() {
    if (!input.trim() || !selectedKbId || loading) return;
    
    const userMessage = input.trim();
    setInput("");
    setLoading(true);
    setError("");
    
    // 添加用户消息
    const newUserMessage: Message = { 
      role: "user", 
      content: userMessage, 
      timestamp: Date.now() 
    };
    setMessages(prev => [...prev, newUserMessage]);
    
    try {
      const res = await fetch('/api/youdao-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: userMessage,
          kbIds: [selectedKbId],
          history: messages.slice(-10).reduce((acc, msg, i, arr) => {
            if (msg.role === "user") {
              const nextMsg = arr[i + 1];
              if (nextMsg && nextMsg.role === "assistant" && nextMsg.content.trim()) {
                acc.push({
                  question: msg.content.trim(),
                  response: nextMsg.content.trim()
                });
              }
            }
            return acc;
          }, [] as { question: string; response: string }[]),
        }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || '对话失败');
      }

      // 处理流式响应
      const reader = res.body?.getReader();
      if (!reader) throw new Error('无法读取响应');

      let assistantContent = "";
      const decoder = new TextDecoder();
      
      // 添加空的助手消息
      const newAssistantMessage: Message = { 
        role: "assistant", 
        content: "", 
        timestamp: Date.now() 
      };
      setMessages(prev => [...prev, newAssistantMessage]);

      let buffer = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;
        
        // 处理 Server-Sent Events 格式
        const lines = buffer.split('\n');
        buffer = lines.pop() || ""; // 保留最后一行（可能不完整）
        
        for (const line of lines) {
          if (line.startsWith('data:')) {
            try {
              const jsonStr = line.substring(5).trim(); // 移除 "data:" 前缀
              if (jsonStr) {
                const data = JSON.parse(jsonStr);
                if (data.result && data.result.response) {
                  assistantContent += data.result.response;
                  
                  // 更新助手消息内容
                  setMessages(prev => {
                    const newMessages = [...prev];
                    const lastIndex = newMessages.length - 1;
                    if (newMessages[lastIndex]?.role === "assistant") {
                      newMessages[lastIndex] = { 
                        role: "assistant", 
                        content: assistantContent,
                        timestamp: Date.now()
                      };
                    }
                    return newMessages;
                  });
                }
              }
            } catch {
              // 忽略解析错误，继续处理下一行
              console.warn('解析 SSE 数据失败:', line);
            }
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '对话失败');
      // 移除可能添加的空助手消息
      setMessages(prev => {
        const newMessages = [...prev];
        if (newMessages[newMessages.length - 1]?.content === "") {
          newMessages.pop();
        }
        return newMessages;
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <MarioBackground>
      <div className="min-h-screen p-4">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* 左侧边栏 - 对话历史 */}
          <div className="md:col-span-1 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg p-4 space-y-4 border-4 border-[#e3b505]">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-bold text-[#b31f24] flex items-center gap-2">
                <span className="text-2xl">📜</span> 历史对话
              </h2>
              <button
                onClick={createNewChat}
                className="mario-button px-4 py-2 text-sm bg-[#b31f24] hover:bg-[#8b1014] text-white rounded-full shadow-md hover:shadow-lg transition-all transform hover:scale-105"
              >
                ✨ 新对话
              </button>
            </div>
            
            <div className="space-y-2 max-h-[calc(100vh-20rem)] overflow-y-auto scrollbar-mario">
              {chatHistories.map((chat) => (
                <div
                  key={chat.id}
                  className={`p-3 rounded-lg cursor-pointer transition-all transform hover:scale-102 ${
                    currentChatId === chat.id
                      ? "bg-[#ffd700]/20 border-2 border-[#ffd700]"
                      : "hover:bg-[#b31f24]/5 border border-[#b31f24]/20"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <h3
                      className="text-sm font-medium text-[#b31f24] truncate flex-1 flex items-center gap-2"
                      onClick={() => loadChat(chat.id)}
                    >
                      <span className="text-lg">🍄</span>
                      {chat.title}
                    </h3>
                    <button
                      onClick={() => deleteChat(chat.id)}
                      className="text-red-500 hover:text-red-700 ml-2 transform hover:scale-110 transition-transform"
                    >
                      ×
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 pl-7">
                    {new Date(chat.updatedAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* 主聊天区域 */}
          <div className="md:col-span-3 flex flex-col h-[calc(100vh-2rem)]">
            {/* 知识库选择 */}
            <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg p-4 mb-4 border-4 border-[#e3b505]">
              <select
                value={selectedKbId}
                onChange={(e) => setSelectedKbId(e.target.value)}
                className="w-full p-3 rounded-lg border-2 border-[#b31f24] focus:border-[#8b1014] focus:ring-2 focus:ring-[#b31f24]/20 outline-none bg-white/90 text-[#b31f24] font-medium"
              >
                <option value="">🎮 选择游戏知识库</option>
                {kbList.map((kb) => (
                  <option key={kb.kbId} value={kb.kbId}>
                    📚 {kb.kbName}
                  </option>
                ))}
              </select>
            </div>

            {/* 消息列表 */}
            <div className="flex-1 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg p-4 mb-4 overflow-y-auto scrollbar-mario border-4 border-[#e3b505]">
              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] p-4 rounded-xl shadow-md transform hover:scale-102 transition-transform ${
                        message.role === "user"
                          ? "bg-[#b31f24] text-white"
                          : "bg-[#ffd700]/10 text-gray-800 border-2 border-[#ffd700]"
                      }`}
                    >
                      {message.role === "assistant" && (
                        <div className="flex items-center gap-2 mb-2 text-[#b31f24] font-medium">
                          <span className="text-xl">🍄</span>
                          马里奥助手
                        </div>
                      )}
                      <p className="whitespace-pre-wrap">{message.content}</p>
                      {message.timestamp && (
                        <p className="text-xs opacity-70 mt-2 text-right">
                          {new Date(message.timestamp).toLocaleString()}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
                {error && (
                  <div className="text-center animate-bounce">
                    <p className="text-red-500 bg-red-50 p-3 rounded-lg inline-block border-2 border-red-200">
                      <span className="text-xl mr-2">⚠️</span>
                      {error}
                    </p>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* 输入区域 */}
            <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg p-4 relative border-4 border-[#e3b505]">
              {/* 快速提问按钮 */}
              <button
                onClick={() => setShowQuickQuestions(!showQuickQuestions)}
                className="absolute -top-12 right-4 mario-button px-6 py-2 bg-[#ffd700] hover:bg-[#e3b505] text-[#b31f24] font-bold rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
              >
                💭 快速提问
              </button>

              {/* 快速提问面板 */}
              {showQuickQuestions && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg p-4 border-4 border-[#ffd700] animate-slideDown">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {quickQuestions.map((q, i) => (
                      <button
                        key={i}
                        onClick={() => handleQuickQuestion(q)}
                        className="text-sm p-3 bg-[#ffd700]/10 hover:bg-[#ffd700]/20 rounded-lg text-[#b31f24] transition-all transform hover:scale-102 text-left flex items-center gap-2"
                      >
                        <span className="text-lg">❓</span>
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 文化小贴士 */}
              <div className="mb-4 p-4 bg-[#ffd700]/10 rounded-lg border-2 border-[#ffd700] transform hover:scale-102 transition-transform">
                <p className="text-sm text-[#b31f24] flex items-center gap-2">
                  <span className="text-xl animate-pulse">💡</span>
                  {culturalTips[currentTip]}
                </p>
              </div>

              {/* 输入框和发送按钮 */}
              <div className="flex gap-3">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSend()}
                  placeholder="输入你的问题..."
                  className="flex-1 p-4 rounded-lg border-2 border-[#b31f24] focus:border-[#8b1014] focus:ring-2 focus:ring-[#b31f24]/20 outline-none bg-white/90 placeholder-[#b31f24]/50"
                />
                <button
                  onClick={handleSend}
                  disabled={!selectedKbId || loading}
                  className={`mario-button px-8 py-2 ${
                    loading
                      ? "bg-gray-400"
                      : "bg-[#b31f24] hover:bg-[#8b1014]"
                  } text-white rounded-lg shadow-md hover:shadow-xl transition-all transform hover:scale-105 min-w-[120px]`}
                >
                  {loading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>思考中...</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <span>发送</span>
                      <span className="text-xl">🚀</span>
                    </div>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .scrollbar-mario::-webkit-scrollbar {
          width: 12px;
        }
        
        .scrollbar-mario::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 6px;
        }
        
        .scrollbar-mario::-webkit-scrollbar-thumb {
          background: #b31f24;
          border-radius: 6px;
          border: 2px solid rgba(255, 255, 255, 0.1);
        }
        
        .scrollbar-mario::-webkit-scrollbar-thumb:hover {
          background: #8b1014;
        }

        @keyframes float-slow {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-20px); }
        }
        
        @keyframes float-medium {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-15px); }
        }
        
        @keyframes float-fast {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }

        @keyframes slideDown {
          from { transform: translateY(-10px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }

        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }

        .animate-slideDown {
          animation: slideDown 0.3s ease-out forwards;
        }

        .cloud {
          font-size: 4rem;
          opacity: 0.3;
        }
      `}</style>
    </MarioBackground>
  );
}