import { Suspense } from 'react';

interface WakaTimeStats {
  data: {
    total_seconds: number;
    daily_average_seconds: number;
    languages: Array<{
      name: string;
      percent: number;
      total_seconds: number;
      digital: string;
      text: string;
      hours: number;
      minutes: number;
    }>;
    range: {
      start: string;
      end: string;
      range: string;
      timezone: string;
      days_including_holidays: number;
      days_minus_holidays: number;
    };
  };
}

async function getWakaTimeStats(): Promise<WakaTimeStats | null> {
  const apiKey = process.env.WAKATIME_API_KEY;
  if (!apiKey) {
    console.error("WakaTime API key is not set.");
    return null;
  }

  try {
    const headers = {
      'Authorization': `Basic ${Buffer.from(apiKey).toString('base64')}`,
      'Content-Type': 'application/json',
    };

    // 获取所有时间的统计数据
    const response = await fetch('https://wakatime.com/api/v1/users/current/stats/all_time', {
      headers,
      next: { 
        revalidate: 3600, // 每小时重新获取一次数据
        tags: ['wakatime-stats'] 
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`WakaTime API request failed with status: ${response.status}`);
      console.error(`Error response: ${errorText}`);
      return null;
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to fetch WakaTime stats:", error);
    return null;
  }
}

function formatTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const days = Math.floor(hours / 24);
  const remainingHours = hours % 24;
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (days > 0) {
    return `${days}天${remainingHours}小时${minutes}分钟`;
  }
  if (hours > 0) {
    return `${hours}小时${minutes}分钟`;
  }
  return `${minutes}分钟`;
}

function PieChart({ languages }: { languages: WakaTimeStats['data']['languages'] }) {
  if (!languages || languages.length === 0) {
    return <div className="text-gray-500">暂无编程语言数据</div>;
  }

  const totalPercent = languages.reduce((acc, lang) => acc + lang.percent, 0);
  const colors = [
    '#E52521', // 马里奥红
    '#049CD8', // 马里奥蓝
    '#FBD000', // 金币黄
    '#43B047', // 管道绿
    '#FF8C00', // 问号块橙
    '#8B4513', // 砖块棕
    '#9400D3', // 毒蘑菇紫
  ];

  const radius = 55;
  const center = radius + 10;
  let currentAngle = 0;
  
  return (
    <div className="flex flex-col items-center">
      <div className="relative group">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-200/30 to-yellow-400/30 rounded-full blur-lg transform scale-110"></div>
        <svg width={center * 2} height={center * 2} className="transform -rotate-90 relative">
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          {languages.slice(0, 7).map((lang, index) => {
            const percentage = (lang.percent / totalPercent) * 100;
            const angle = (percentage / 100) * Math.PI * 2;
            
            const startX = center + radius * Math.cos(currentAngle);
            const startY = center + radius * Math.sin(currentAngle);
            const endX = center + radius * Math.cos(currentAngle + angle);
            const endY = center + radius * Math.sin(currentAngle + angle);
            
            const largeArcFlag = percentage > 50 ? 1 : 0;
            const pathData = [
              `M ${center},${center}`,
              `L ${startX},${startY}`,
              `A ${radius},${radius} 0 ${largeArcFlag} 1 ${endX},${endY}`,
              'Z'
            ].join(' ');
            
            const path = (
              <path
                key={lang.name}
                d={pathData}
                fill={colors[index]}
                stroke="#FFD700"
                strokeWidth="2"
                className="transition-all duration-300 hover:opacity-80 hover:scale-105 cursor-pointer"
                style={{
                  filter: 'url(#glow)',
                  transformOrigin: 'center'
                }}
              />
            );
            
            currentAngle += angle;
            return path;
          })}
          <circle 
            cx={center} 
            cy={center} 
            r={radius * 0.6} 
            fill="url(#centerGradient)"
            className="opacity-90"
            style={{filter: 'url(#glow)'}}
          />
          <radialGradient id="centerGradient">
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#FFA500" />
          </radialGradient>
        </svg>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
          <div className="text-xl font-bold text-red-600 drop-shadow-lg">{languages[0].percent.toFixed(0)}%</div>
          <div className="text-xs font-medium text-gray-700 drop-shadow">{languages[0].name}</div>
        </div>
      </div>
      
      <div className="mt-4 grid grid-cols-2 gap-2 w-full bg-gradient-to-br from-red-50/50 via-yellow-50/50 to-blue-50/50 p-3 rounded-lg border-2 border-yellow-400 shadow-inner">
        {languages.slice(0, 7).map((lang, index) => (
          <div key={lang.name} 
               className="flex items-center gap-2 p-1.5 rounded-md hover:bg-white/70 transition-all duration-300 hover:scale-105"
               style={{
                 background: `linear-gradient(135deg, ${colors[index]}15, ${colors[index]}05)`
               }}>
            <div className="w-3 h-3 rounded-full shadow-sm" style={{ backgroundColor: colors[index] }} />
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-gray-700 truncate">{lang.name}</div>
              <div className="text-xs text-red-600">{formatTime(lang.total_seconds)}</div>
            </div>
            <span className="text-xs font-medium text-red-600">{lang.percent.toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

async function WakaTimeData() {
  const stats = await getWakaTimeStats();
  
  if (!stats) {
    return (
      <div className="text-red-500 text-center p-4 bg-red-50 rounded-lg border-2 border-yellow-400">
        <div className="text-2xl mb-1">🍄</div>
        无法获取编程统计数据，请确保已正确配置 WakaTime API Key
      </div>
    );
  }

  // 如果days_minus_holidays为0或undefined，使用7天作为默认值
  const days = stats.data.range.days_minus_holidays || 7;
  const dailyAverage = stats.data.total_seconds / days;
  const totalHours = Math.floor(stats.data.total_seconds / 3600);
  const averageHours = Math.floor(dailyAverage / 3600);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 总编程时间卡片 */}
        <div className="bg-gradient-to-br from-red-50 to-blue-50 p-4 rounded-lg shadow-sm border-2 border-yellow-400 relative overflow-hidden">
          {/* 装饰性背景元素 */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-200/20 to-yellow-400/20 rounded-full blur-xl transform translate-x-16 -translate-y-8"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-br from-red-200/20 to-red-400/20 rounded-full blur-lg transform -translate-x-12 translate-y-12"></div>
          
          <div className="relative">
            {/* 标题部分 */}
            <div className="flex items-center mb-4">
              <span className="text-2xl mr-2">🍄</span>
              <h3 className="text-lg font-bold text-gray-800">总编程时间</h3>
            </div>

            {/* 主要时间显示 */}
            <div className="mb-6">
              <p className="text-3xl font-bold text-red-600 mb-2 flex items-center">
                {formatTime(stats.data.total_seconds)}
                <span className="text-sm text-red-400 ml-2">⚡</span>
              </p>
              <div className="flex items-center text-gray-500 text-sm">
                <span className="text-lg mr-1.5">⭐</span>
                <span>日均: {formatTime(dailyAverage)}</span>
              </div>
            </div>

            {/* 统计数据网格 */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/50 rounded-lg p-2 border border-yellow-200">
                <div className="text-xs text-gray-500 mb-1">总计小时</div>
                <div className="text-lg font-bold text-red-500">{totalHours}h</div>
              </div>
              <div className="bg-white/50 rounded-lg p-2 border border-yellow-200">
                <div className="text-xs text-gray-500 mb-1">日均小时</div>
                <div className="text-lg font-bold text-red-500">{averageHours}h</div>
              </div>
              <div className="bg-white/50 rounded-lg p-2 border border-yellow-200">
                <div className="text-xs text-gray-500 mb-1">统计天数</div>
                <div className="text-lg font-bold text-red-500">{days}天</div>
              </div>
              <div className="bg-white/50 rounded-lg p-2 border border-yellow-200">
                <div className="text-xs text-gray-500 mb-1">编程效率</div>
                <div className="text-lg font-bold text-red-500">{Math.round(averageHours/24 * 100)}%</div>
              </div>
            </div>

            {/* 底部装饰 */}
            <div className="flex justify-end mt-3">
              <div className="flex space-x-1">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-yellow-400/60"></div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 编程语言统计卡片 */}
        <div className="bg-gradient-to-br from-blue-50 to-red-50 p-4 rounded-lg shadow-sm border-2 border-yellow-400">
          <div className="flex items-center mb-3">
            <span className="text-2xl mr-2">🌟</span>
            <h3 className="text-lg font-bold text-gray-800">
              常用编程语言
            </h3>
          </div>
          <PieChart languages={stats.data.languages} />
        </div>
      </div>
    </div>
  );
}

export default function WakaTimeStats() {
  return (
    <footer className="mario-card bg-white/80 backdrop-blur-sm p-6 mt-auto w-full z-10 border-t-2 border-yellow-400">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-4">
          <span className="text-3xl mr-2">🎮</span>
          <h2 className="text-2xl font-bold text-gray-800">
            马里奥的编程时光
          </h2>
        </div>
        <Suspense fallback={
          <div className="text-center p-4">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-red-200 border-t-red-500" />
            <p className="text-red-600 mt-2">正在获取编程数据...</p>
          </div>
        }>
          <WakaTimeData />
        </Suspense>
        <div className="mt-6 text-center text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} 马里奥的编程乐园
        </div>
      </div>
    </footer>
  );
} 