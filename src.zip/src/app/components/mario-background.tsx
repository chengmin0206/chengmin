interface MarioBackgroundProps {
  children: React.ReactNode;
}

export default function MarioBackground({ children }: MarioBackgroundProps) {
  return (
    <div 
      className="min-h-screen w-full"
      style={{
        backgroundImage: "url('/img/制作马里奥游戏图片 (12).png')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        backgroundAttachment: 'fixed'
      }}
    >
      {children}
    </div>
  );
} 