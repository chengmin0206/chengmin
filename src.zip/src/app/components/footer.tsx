export default function Footer() {
  return (
    <footer className="mario-section p-8 mt-12 text-center">
      <div className="container mx-auto">
        <p className="text-lg font-bold text-green-600 mb-4">
          &ldquo;像马里奥一样在编程世界中不断探索！&rdquo;
        </p>
        <p className="text-gray-600 text-sm">
          2023级新闻学1班 P231014781 成敏 2025年6月
        </p>
      </div>
    </footer>
  );
} 