import Image from "next/image";
import Link from "next/link";

export interface ExerciseCardProps {
  id: string | number;
  title: string;
  description: string;
  imageUrl?: string;
  link?: string;
  tags?: string[];
}

export default function DdddddExerciseCard({ title, description, imageUrl, link, tags }: ExerciseCardProps) {
  const cardContent = (
    <>
      {imageUrl && (
        <div className="relative w-full h-48 overflow-hidden">
          <Image
            src={imageUrl}
            alt={title || 'Exercise image'}
            fill
            style={{ objectFit: 'cover' }}
            className="transition-transform duration-700 group-hover:scale-110"
          />
          {/* 马里奥风格遮罩 */}
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 via-green-900/20 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-br from-red-900/30 via-transparent to-blue-900/20"></div>
          
          {/* 马里奥装饰角落 */}
          <div className="absolute top-2 left-2 w-6 h-6 border-l-2 border-t-2 border-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          <div className="absolute top-2 right-2 w-6 h-6 border-r-2 border-t-2 border-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          <div className="absolute bottom-2 left-2 w-6 h-6 border-l-2 border-b-2 border-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          <div className="absolute bottom-2 right-2 w-6 h-6 border-r-2 border-b-2 border-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          
          {/* 马里奥砖块装饰 */}
          <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-8 h-6 bg-orange-600 border border-orange-700 rounded-sm opacity-0 group-hover:opacity-80 transition-opacity duration-500"></div>
        </div>
      )}
      
      <div className="p-6 flex flex-col flex-grow relative">
        {/* 关卡标题装饰 */}
        <div className="absolute top-4 left-4 level-badge text-xs">
          {typeof tags?.[2] === 'string' && tags[2].includes('Level') ? tags[2].split(' ')[1] : '🎮'}
        </div>
        
        <h3 className="text-xl font-bold text-gray-800 mb-3 pt-8 tracking-wide mario-text-gradient">
          {title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 h-20 overflow-y-auto flex-grow leading-relaxed">
          {description}
        </p>
        
        {tags && tags.length > 0 && (
          <div className="mb-5">
            {tags.map((tag) => (
              <span
                key={tag}
                className={`inline-block text-xs font-medium mr-2 mb-2 px-3 py-1 rounded-full transition-colors border-2 ${
                  tag.includes('HTML') ? 'bg-red-100 text-red-700 border-red-300' :
                  tag.includes('CSS') ? 'bg-blue-100 text-blue-700 border-blue-300' :
                  tag.includes('JavaScript') ? 'bg-yellow-100 text-yellow-700 border-yellow-300' :
                  tag.includes('React') ? 'bg-cyan-100 text-cyan-700 border-cyan-300' :
                  tag.includes('Next.js') ? 'bg-purple-100 text-purple-700 border-purple-300' :
                  tag.includes('Level') ? 'bg-green-100 text-green-700 border-green-300' :
                  'bg-gray-100 text-gray-700 border-gray-300'
                }`}
              >
                {tag}
              </span>
            ))}
          </div>
        )}
        
        <div className="mt-auto relative">
          {/* 底部金币装饰 */}
          <div className="absolute -top-6 right-0 mario-coin w-6 h-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          
          <div className="mario-button px-4 py-2 text-sm font-bold w-full text-center transition-all duration-300 hover:scale-105">
            <span className="mr-2">🚀 开始闯关</span>
            <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
          </div>
        </div>
      </div>
    </>
  );

  return (
    <div className="relative group">
      {/* 外层马里奥光晕效果 */}
      <div className="absolute -inset-1 bg-gradient-to-r from-red-600/30 via-yellow-500/30 to-green-600/30 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition duration-700 mario-glow"></div>
      
      {/* 主卡片 - 马里奥主题 */}
      <div className="mario-card relative h-full flex flex-col transition-all duration-500 ease-in-out group-hover:shadow-xl group-hover:shadow-blue-900/20">
        
        {/* 马里奥传统纹样装饰 */}
        <div className="absolute top-4 right-4 w-8 h-8 opacity-20 group-hover:opacity-40 transition-opacity duration-500">
          <div className="w-full h-full bg-yellow-400 border-2 border-yellow-600 rounded-full mario-coin">
          </div>
        </div>
        
        {/* Boss关卡特殊装饰 */}
        {tags?.some(tag => tag.includes('Boss')) && (
          <div className="absolute top-2 left-2 text-2xl animate-bounce">
            👑
          </div>
        )}
        
        {link ? (
          <Link href={link} target="_blank" rel="noopener noreferrer" className="flex flex-col h-full">
            {cardContent}
          </Link>
        ) : (
          <div className="flex flex-col h-full">{cardContent}</div>
        )}
      </div>
    </div>
  );
} 