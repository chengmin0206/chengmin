import './globals.css'
import type { Metadata } from 'next'
import { Geist, Geist_Mono } from "next/font/google";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: '超级学习工坊',
  description: '像马里奥一样在编程世界中探索和成长！',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen relative overflow-x-hidden`}
      >
        {/* 装饰性云朵背景 */}
        <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0">
          <div className="cloud absolute top-[5%] left-[5%] animate-float-slow opacity-90 text-[#E6F3FF] text-6xl">☁️</div>
          <div className="cloud absolute top-[15%] right-[10%] animate-float-medium opacity-90 text-[#E6F3FF] text-7xl">☁️</div>
          <div className="cloud absolute top-[30%] left-[20%] animate-float-fast opacity-90 text-[#E6F3FF] text-5xl">☁️</div>
          <div className="cloud absolute top-[45%] right-[25%] animate-float-medium opacity-90 text-[#E6F3FF] text-6xl">☁️</div>
          <div className="cloud absolute top-[60%] left-[15%] animate-float-slow opacity-90 text-[#E6F3FF] text-7xl">☁️</div>
        </div>
        
        {/* 马里奥风格背景装饰 */}
        <div className="fixed inset-0 pointer-events-none opacity-30 z-0">
          {/* 砖块装饰 */}
          <div className="absolute top-20 left-10 w-16 h-12 bg-[#B35F00] border-2 border-[#8B4513] rounded-sm mario-brick"></div>
          <div className="absolute top-20 left-28 w-16 h-12 bg-[#B35F00] border-2 border-[#8B4513] rounded-sm mario-brick"></div>
          <div className="absolute top-20 left-46 w-16 h-12 bg-[#B35F00] border-2 border-[#8B4513] rounded-sm mario-brick"></div>
          
          <div className="absolute top-1/4 right-20 w-16 h-12 bg-[#B35F00] border-2 border-[#8B4513] rounded-sm mario-brick"></div>
          <div className="absolute top-1/4 right-38 w-16 h-12 bg-[#B35F00] border-2 border-[#8B4513] rounded-sm mario-brick"></div>
          
          {/* 金币装饰 */}
          <div className="absolute top-1/3 left-1/4 w-8 h-8 bg-[#FFD700] border-2 border-[#DAA520] rounded-full mario-coin"></div>
          <div className="absolute bottom-1/3 right-1/4 w-8 h-8 bg-[#FFD700] border-2 border-[#DAA520] rounded-full mario-coin"></div>
          <div className="absolute top-1/2 left-1/2 w-8 h-8 bg-[#FFD700] border-2 border-[#DAA520] rounded-full mario-coin"></div>
          
          {/* 管道装饰 */}
          <div className="absolute bottom-0 left-20 w-12 h-24 bg-[#2E7D32] border-4 border-[#1B5E20] rounded-t-lg"></div>
          <div className="absolute bottom-0 right-32 w-12 h-32 bg-[#2E7D32] border-4 border-[#1B5E20] rounded-t-lg"></div>
        </div>
        
        {/* 主要内容 */}
        <main className="relative z-10 min-h-[calc(100vh-60px)]">
          {children}
        </main>
      </body>
    </html>
  )
}
